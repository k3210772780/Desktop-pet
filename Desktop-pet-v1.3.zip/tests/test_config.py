from desktop_pet.config import DEFAULTS, load_config


def test_defaults_have_expected_keys():
    assert set(DEFAULTS) == {"auto_walk", "follow_mouse", "walk_speed", "do_not_disturb"}
    assert set(load_config()) == set(DEFAULTS)
