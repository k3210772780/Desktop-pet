from __future__ import annotations

import math, random, time, tkinter as tk
from collections import deque
from enum import Enum
from pathlib import Path
from tkinter import ttk
from .config import load_config, save_config
from .skin_editor import SkinEditor
from .sprites import SpritePlayer
from .windows import (ActivityPoller, area_at, clamp_to_area, cursor_position,
                      monitor_work_areas, nearest_area, set_window_position)


class Mode(str, Enum):
    NORMAL = "NORMAL"
    DO_NOT_DISTURB = "DO_NOT_DISTURB"


class Behavior(str, Enum):
    IDLE="IDLE"; WALK="WALK"; TYPING="TYPING"; MOUSE="MOUSE"; CLICK="CLICK"
    SLEEP="SLEEP"; WAKE="WAKE"; EXPRESSION="EXPRESSION"; DRAG="DRAG"


class DesktopPetApp:
    SIZE=180; TRANSPARENT="#ff00ff"

    def __init__(self):
        self.root=tk.Tk(); self.root.title("双屏桌宠 v1.8"); self.root.overrideredirect(True)
        self.root.attributes("-topmost",True); self.root.attributes("-transparentcolor",self.TRANSPARENT)
        self.root.configure(bg=self.TRANSPARENT); self.root.geometry(f"{self.SIZE}x{self.SIZE}+0+0")
        self.canvas=tk.Canvas(self.root,width=self.SIZE,height=self.SIZE,bg=self.TRANSPARENT,highlightthickness=0)
        self.canvas.pack(); self.config=load_config(); self.sprites=SpritePlayer(self.root)
        self.activity=ActivityPoller(); self.areas=monitor_work_areas()
        self.mode=Mode.DO_NOT_DISTURB if self.config["do_not_disturb"] else Mode.NORMAL
        self.behavior=Behavior.IDLE; self.behavior_since=time.monotonic(); self.facing="right"; self.frame=0
        self.last_key=0.; self.last_mouse=0.; self.key_times=deque(maxlen=30)
        self.target=None; self.drag_offset=None; self.drag_previous_x=None; self.drag_moved=False
        self.animation_override="loaf" if self.mode==Mode.DO_NOT_DISTURB else None
        self.expression_until=0.; self.pending_expression=None
        self.bubble=None; self.bubble_timeout_id=None
        self.root.bind("<ButtonPress-1>",self._left_press); self.root.bind("<B1-Motion>",self._drag_move)
        self.root.bind("<ButtonRelease-1>",self._drag_end); self.root.bind("<Button-3>",self._show_menu)
        self._build_menu(); self.root.after(120,self._initial_position); self.root.after(33,self._tick)
        self.root.after(3000,self._decide)

    def run(self): self.root.mainloop()

    def _build_menu(self):
        old=getattr(self,"menu",None)
        if old is not None:
            try:old.destroy()
            except tk.TclError:pass
        self.menu=tk.Menu(self.root,tearoff=False,postcommand=self._prepare_menu)
        self.menu.add_command(label="固定桌宠",command=self._toggle_movement)
        self.menu.add_separator(); self.expressions=tk.Menu(self.menu,tearoff=False)
        self.expressions.add_command(label="停止当前动作 / 回到待机",command=self._return_to_idle)
        self.expressions.add_separator()
        if self.sprites.expression_menu:
            for item in self.sprites.expression_menu:
                self.expressions.add_command(
                    label=item["name"],
                    command=lambda a=item["action"],d=item["duration"]:self._request_expression(a,d))
        else:
            self.expressions.add_command(label="暂无自定义表情",state="disabled")
        self.menu.add_cascade(label="选择表情",menu=self.expressions)
        self.menu.add_separator(); self.dnd_var=tk.BooleanVar(value=self.mode==Mode.DO_NOT_DISTURB)
        self.menu.add_checkbutton(label="工作免打扰",variable=self.dnd_var,command=self._toggle_dnd)
        self.menu.add_command(label="设置…",command=self._settings_window); self.menu.add_separator()
        self.menu.add_command(label="退出桌宠",command=self.root.destroy)

    def _prepare_menu(self):
        dnd=self.mode==Mode.DO_NOT_DISTURB
        enabled=bool(self.config["movement_enabled"])
        self.menu.entryconfigure(0,label="固定桌宠" if enabled else "允许移动",
                                 state="disabled" if dnd else "normal")
        self.dnd_var.set(dnd)

    def _toggle_movement(self):
        enabled=not bool(self.config["movement_enabled"]); self.config["movement_enabled"]=enabled
        if not enabled:self._set_behavior(Behavior.IDLE)
        save_config(self.config)

    def _set_behavior(self,b,keep=False):
        if b!=self.behavior: self.behavior=b; self.behavior_since=time.monotonic()
        if b!=Behavior.WALK:self.target=None
        if not keep and b!=Behavior.EXPRESSION:self.animation_override=None

    def _initial_position(self):
        if self.areas:
            a=self.areas[0]
            self._move(a.center_x-self.SIZE//2,a.bottom-self.SIZE)
            if not self.config.get("screen_intro_shown",False):
                self.config["screen_intro_shown"]=True; save_config(self.config)
                self.root.after(350,lambda:self._show_bubble(message=f"已识别 {len(self.areas)} 块屏幕",duration=3000))
            if self.sprites.error:
                self.root.after(500,lambda:self._show_bubble(message=f"皮肤加载失败：{self.sprites.error}",duration=6000))
    def _position(self): return self.root.winfo_x(),self.root.winfo_y()
    def _move(self,x,y):
        set_window_position(self.root.winfo_id(),int(x),int(y),self.SIZE,self.SIZE)

    def _choose_walk(self):
        if self.mode!=Mode.NORMAL or not self.config["movement_enabled"]:return
        self.areas=monitor_work_areas() or self.areas; a=random.choice(self.areas)
        x=random.randint(a.left,max(a.left,a.right-self.SIZE)); cx,_=self._position()
        _,cy=self._position(); y=min(max(cy,a.top),a.bottom-self.SIZE)
        self.facing="right" if x>=cx else "left"; self._set_behavior(Behavior.WALK)
        self.target=(x,y)

    def _return_to_idle(self):
        if self.mode!=Mode.NORMAL:return
        self._set_behavior(Behavior.WAKE if self.behavior==Behavior.SLEEP else Behavior.IDLE)

    def _request_expression(self,anim,duration):
        if self.behavior==Behavior.SLEEP:
            self.pending_expression=(anim,duration); self._set_behavior(Behavior.WAKE); return
        self._play_expression(anim,duration)
    def _play_expression(self,anim,duration):
        self.animation_override=anim; self.expression_until=time.monotonic()+duration
        self._set_behavior(Behavior.EXPRESSION,keep=True)

    def _toggle_dnd(self):
        enabled=bool(self.dnd_var.get())
        if enabled:
            self.mode=Mode.DO_NOT_DISTURB; self.pending_expression=None; self.animation_override="loaf"
            self._set_behavior(Behavior.IDLE,keep=True)
        else:
            self.mode=Mode.NORMAL; self.animation_override=None; self._set_behavior(Behavior.WAKE)
        self.config["do_not_disturb"]=enabled; save_config(self.config)

    def _decide(self):
        now=time.monotonic()
        if self.mode!=Mode.NORMAL or self.behavior in (Behavior.WALK,Behavior.EXPRESSION,Behavior.DRAG):pass
        elif now-self.activity.last_activity>120:self._set_behavior(Behavior.SLEEP)
        elif now-self.last_key<1.6:self._set_behavior(Behavior.TYPING)
        elif now-self.last_mouse<1.:self._set_behavior(Behavior.MOUSE)
        elif self.config["movement_enabled"] and not self.config["follow_cursor_position"] and random.random()<.48:self._choose_walk()
        else:self._set_behavior(Behavior.IDLE)
        self.root.after(3000,self._decide)

    def _tick(self):
        self.frame+=1; now=time.monotonic(); events=self.activity.poll()
        if self.mode!=Mode.NORMAL or self.behavior in (Behavior.EXPRESSION,Behavior.DRAG):events=set()
        if "typing" in events:
            self.last_key=now; self.key_times.append(now)
            self._set_behavior(Behavior.WAKE if self.behavior==Behavior.SLEEP else Behavior.TYPING)
        elif "click" in events and self.behavior==Behavior.SLEEP:
            self._set_behavior(Behavior.WAKE)
        elif "mouse" in events:
            self.last_mouse=now
            if self.behavior==Behavior.SLEEP:self._set_behavior(Behavior.WAKE)
            elif self.config["movement_enabled"] and self.config["follow_cursor_position"] and self.behavior!=Behavior.TYPING:
                self._follow_cursor()
            elif self.behavior not in (Behavior.WALK,Behavior.TYPING):self._set_behavior(Behavior.MOUSE)
        if self.behavior==Behavior.WAKE and now-self.behavior_since>.9:
            if self.pending_expression:
                a,d=self.pending_expression; self.pending_expression=None; self._play_expression(a,d)
            else:self._set_behavior(Behavior.IDLE)
        elif self.behavior==Behavior.EXPRESSION and now>=self.expression_until:
            if self.mode==Mode.DO_NOT_DISTURB:
                self.animation_override="loaf"; self._set_behavior(Behavior.IDLE,keep=True)
            else:self._set_behavior(Behavior.IDLE)
        elif self.behavior in (Behavior.CLICK,Behavior.MOUSE) and now-self.behavior_since>1:self._set_behavior(Behavior.IDLE)
        elif self.behavior==Behavior.TYPING and now-self.last_key>1.8:self._set_behavior(Behavior.IDLE)
        if self.behavior==Behavior.WALK and self.target and self.drag_offset is None:
            x,y=self._position(); tx,ty=self.target; speed=int(self.config["walk_speed"]); dx=tx-x; dy=ty-y
            if abs(dx)>1:self.facing="right" if dx>0 else "left"
            distance=max(1.0,math.hypot(dx,dy)); step=min(speed,distance)
            nx=x+dx/distance*step; ny=y+dy/distance*step
            probe=area_at(int(nx)+self.SIZE//2,int(ny)+self.SIZE//2,self.areas)
            if probe is None:
                current=nearest_area(x+self.SIZE//2,y+self.SIZE//2,self.areas)
                nx,ny=clamp_to_area(nx,ny,self.SIZE,self.SIZE,current)
                self._move(nx,ny); self.facing="left" if self.facing=="right" else "right"
                self._set_behavior(Behavior.IDLE); self.target=None
                self._draw(); self.root.after(33,self._tick); return
            nx,ny=clamp_to_area(nx,ny,self.SIZE,self.SIZE,probe); self._move(nx,ny)
            if distance<=speed:self._move(tx,ty); self._set_behavior(Behavior.IDLE)
        self._draw(); self.root.after(33,self._tick)

    def _animation(self):
        if self.behavior==Behavior.DRAG:return "drag"
        if self.animation_override:return self.animation_override
        if self.behavior==Behavior.WALK:return "walk"
        if self.behavior==Behavior.TYPING:
            return "typingfast" if sum(t>=time.monotonic()-1 for t in self.key_times)>=7 else "typing"
        if self.behavior==Behavior.SLEEP:return "sleep"
        if self.behavior==Behavior.WAKE:return "wakeup"
        if self.behavior==Behavior.CLICK:return "pet"
        if self.behavior==Behavior.MOUSE:return "crouch"
        if self.mode==Mode.DO_NOT_DISTURB:return "loaf"
        return "idle"

    def _draw(self):
        self.canvas.delete("all"); img=self.sprites.frame(self._animation(),time.monotonic()-self.behavior_since,self.facing)
        if img is not None:self.canvas.create_image(self.SIZE//2,self.SIZE,image=img,anchor="s"); return
        b=2*math.sin(self.frame/4) if self.behavior in (Behavior.WALK,Behavior.TYPING) else 0; c=self.canvas
        c.create_oval(59,48+b,82,76+b,fill="#8bd3dd"); c.create_oval(98,48+b,121,76+b,fill="#8bd3dd")
        c.create_oval(52,62+b,128,132+b,fill="#8bd3dd",outline="#29303b",width=3)

    def _follow_cursor(self):
        if self.mode!=Mode.NORMAL:return
        cx,cy=cursor_position(); a=area_at(cx,cy,self.areas) or nearest_area(cx,cy,self.areas)
        tx,ty=clamp_to_area(cx-self.SIZE//2+55,cy-self.SIZE//2+55,self.SIZE,self.SIZE,a)
        x,_=self._position(); self.facing="right" if tx>=x else "left"
        self._set_behavior(Behavior.WALK); self.target=(tx,ty)
    def _left_press(self,e):
        self.drag_offset=(e.x,e.y); self.drag_previous_x=e.x_root; self.drag_moved=False
    def _drag_move(self,e):
        if self.drag_offset:
            if not self.drag_moved and (abs(e.x-self.drag_offset[0])>=3 or abs(e.y-self.drag_offset[1])>=3):
                self.drag_moved=True; self._set_behavior(Behavior.DRAG)
            if not self.drag_moved:return
            if self.drag_previous_x is not None and abs(e.x_root-self.drag_previous_x)>=3:self.facing="right" if e.x_root>self.drag_previous_x else "left"
            self.drag_previous_x=e.x_root
            a=area_at(e.x_root,e.y_root,self.areas) or nearest_area(e.x_root,e.y_root,self.areas)
            x,y=clamp_to_area(e.x_root-self.drag_offset[0],e.y_root-self.drag_offset[1],self.SIZE,self.SIZE,a)
            self._move(x,y)
    def _drag_end(self,e):
        if not self.drag_offset:return
        was_dragged=self.drag_moved
        self.drag_offset=None; self.drag_previous_x=None; x,y=self._position(); a=nearest_area(x+self.SIZE//2,y+self.SIZE//2,self.areas)
        x,y=clamp_to_area(x,y,self.SIZE,self.SIZE,a); self._move(x,y)
        if self.mode==Mode.DO_NOT_DISTURB:self.animation_override="loaf"; self._set_behavior(Behavior.IDLE,keep=True)
        elif was_dragged:self._set_behavior(Behavior.IDLE)
        else:self._set_behavior(Behavior.CLICK)
        self.drag_moved=False
    def _show_menu(self,e):self.menu.tk_popup(e.x_root,e.y_root)
    def _show_bubble(self,message,duration=2200):
        self._hide_bubble(); self.bubble=tk.Toplevel(self.root); self.bubble.overrideredirect(True); self.bubble.attributes("-topmost",True)
        tk.Label(self.bubble,text=message,bg="#20242c",fg="white",padx=12,pady=8).pack()
        self.bubble.update_idletasks(); x,y=self._position(); bw=self.bubble.winfo_reqwidth(); bh=self.bubble.winfo_reqheight()
        bx=x+(self.SIZE-bw)//2; by=y-bh-8
        a=nearest_area(x+self.SIZE//2,y+self.SIZE//2,self.areas)
        bx=min(max(bx,a.left),a.right-bw); by=min(max(by,a.top),a.bottom-bh)
        set_window_position(self.bubble.winfo_id(),bx,by,bw,bh)
        self.bubble_timeout_id=self.root.after(duration,self._hide_bubble)
    def _hide_bubble(self):
        if self.bubble_timeout_id is not None:
            try:self.root.after_cancel(self.bubble_timeout_id)
            except tk.TclError:pass
            self.bubble_timeout_id=None
        if self.bubble:self.bubble.destroy(); self.bubble=None
    def _settings_window(self):
        existing=getattr(self,"settings_window",None)
        if existing and existing.winfo_exists():existing.lift(); return
        w=tk.Toplevel(self.root); self.settings_window=w; w.title("桌宠设置 v1.8"); w.attributes("-topmost",True)
        w.geometry("850x720"); notebook=ttk.Notebook(w); notebook.pack(fill="both",expand=True)
        body=ttk.Frame(notebook,padding=18); notebook.add(body,text="基础设置")
        follow=tk.BooleanVar(value=self.config["follow_cursor_position"])
        speed=tk.IntVar(value=self.config["walk_speed"]); dnd=tk.BooleanVar(value=self.mode==Mode.DO_NOT_DISTURB)
        scale=tk.IntVar(value=self._skin_scale())
        ttk.Checkbutton(body,text="位置跟随鼠标移动",variable=follow).grid(row=0,column=0,columnspan=2,sticky="w",pady=6)
        ttk.Label(body,text="移动速度").grid(row=1,column=0,sticky="w")
        ttk.Scale(body,from_=2,to=10,variable=speed).grid(row=1,column=1,sticky="ew")
        ttk.Label(body,text="桌宠显示缩放").grid(row=2,column=0,sticky="w",pady=8)
        ttk.Spinbox(body,from_=10,to=200,textvariable=scale,width=8).grid(row=2,column=1,sticky="w")
        ttk.Label(body,text="%（在皮肤与动作中应用后生效）").grid(row=2,column=1,padx=(70,0),sticky="w")
        ttk.Checkbutton(body,text="启动后保持工作免打扰",variable=dnd).grid(row=3,column=0,columnspan=2,sticky="w",pady=6)
        body.columnconfigure(1,weight=1)
        def save():
            self.config.update(follow_cursor_position=follow.get(),walk_speed=speed.get()); save_config(self.config); w.destroy()
            if dnd.get()!=(self.mode==Mode.DO_NOT_DISTURB):self.dnd_var.set(dnd.get()); self._toggle_dnd()
        ttk.Button(body,text="保存基础设置",command=save).grid(row=4,column=0,pady=18,sticky="w")
        ttk.Button(body,text="关闭",command=w.destroy).grid(row=4,column=1,pady=18,sticky="w")
        skin=SkinEditor(notebook,Path(__file__).resolve().parent.parent/"assets"/"pixelpaws",self._reload_skin,scale)
        notebook.add(skin,text="皮肤与动作")

    def _skin_scale(self):
        try:
            import json
            path=Path(__file__).resolve().parent.parent/"assets"/"pixelpaws"/"manifest.json"
            data=json.loads(path.read_text(encoding="utf-8"))
            return int(data.get("scalePercent",round(100/int(data.get("subsample",1)))))
        except (OSError,ValueError,ZeroDivisionError):return 100

    def _reload_skin(self):
        replacement=SpritePlayer(self.root)
        if replacement.error:raise ValueError(replacement.error)
        self.sprites=replacement; self._build_menu(); self._set_behavior(Behavior.IDLE)
