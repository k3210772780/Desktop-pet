# v1.8 皮肤与动作配置说明

推荐直接在桌宠上右键打开“设置…”，进入“皮肤与动作”页面完成图片读取、网格裁切、动作配置和预览，不再需要手写 JSON。

皮肤目录固定为：

```text
assets/pixelpaws/
├─ spritesheet.png
└─ manifest.json
```

替换这两个文件并重新启动程序，即可更换皮肤和右键“选择表情”菜单。

## 基本尺寸

```json
{
  "name": "我的皮肤",
  "sheet": "spritesheet.png",
  "imageWidth": 840,
  "imageHeight": 3300,
  "cropWidth": 210,
  "cropHeight": 300,
  "scalePercent": 50,
  "defaultFacing": "right"
}
```

- `imageWidth`、`imageHeight`：PNG原图的实际宽高。
- `cropWidth`、`cropHeight`：每个动作帧的裁剪宽高。
- 程序自动计算列数和行数，图片宽高必须能被裁剪宽高整除。
- `scalePercent`：桌宠显示缩放百分比，可在基础设置中调整。
- `defaultFacing`：精灵图素材原本朝向，可在裁切区域选择向左或向右。
- 缩小后的单帧建议不要超过180×180，否则超出桌宠窗口的部分会被裁掉。
- PNG应带透明通道，所有格子尺寸必须一致，角色尽量底部对齐。

帧编号从左到右、从上到下，从0开始：

```text
0  1  2  3
4  5  6  7
8  9  10 11
```

## 定义动作

```json
"animations": {
  "idle": {"frames": [0, 1], "fps": 2, "loop": true},
  "walk": {"frames": [4, 5, 6, 7], "fps": 10, "loop": true},
  "happy": {"frames": [12, 13], "fps": 5, "loop": true}
}
```

- 动作键（如 `happy`）是程序读取的动作名称。
- `frames`是播放顺序，可以重复帧。
- `fps`是每秒帧数，必须大于0。
- `loop`决定是否循环；非循环动作停在最后一帧，直到动作时间结束。

每套皮肤必须提供以下四个基础动作键：

```text
idle walk pet typing
```

它们分别对应待机、移动、用户点击桌宠和检测到键盘输入。缺少任意一个时，程序会提示皮肤配置不完整并使用占位角色。

除了四个必要动作，其余都作为“自定义表情”管理。用户可以按需要添加任意数量，也可以完全不添加；只有四个必要动作时桌宠仍能正常运行。躲猫猫功能已经移除。

素材原始朝向在裁切区域选择，程序会自动生成相反方向的水平镜像。

## 定义右键表情菜单

```json
"expressionMenu": [
  {"name": "开心", "action": "happy", "duration": 3.0},
  {"name": "打哈欠", "action": "yawn", "duration": 2.5}
]
```

- `name`：右键菜单中显示的文字，可以使用中文或其他语言。
- `action`：必须与 `animations` 中的动作键完全一致。
- `duration`：该表情播放多少秒，必须大于0。
- 菜单顺序与数组顺序一致。
- 可以增加、删除或重排任意表情，不需要修改程序。

如果 `expressionMenu` 是空数组，右键“选择表情”中会显示“暂无可用表情”。

## 完整最小示例

```json
{
  "name": "两动作小猫",
  "sheet": "spritesheet.png",
  "imageWidth": 1024,
  "imageHeight": 128,
  "cropWidth": 128,
  "cropHeight": 128,
  "scalePercent": 100,
  "defaultFacing": "right",
  "animations": {
    "idle": {"frames": [0, 1], "fps": 2, "loop": true},
    "walk": {"frames": [2, 3], "fps": 8, "loop": true},
    "pet": {"frames": [4, 5], "fps": 6, "loop": false},
    "typing": {"frames": [6, 7], "fps": 6, "loop": true}
  },
  "expressionMenu": [
    {"name": "回应我", "action": "pet", "duration": 3.0}
  ]
}
```

启动时程序会检查：图片实际尺寸、网格是否能整除、帧是否越界、动作速度以及菜单动作是否存在。配置错误时会显示“皮肤加载失败”，并安全回退到占位图形。
