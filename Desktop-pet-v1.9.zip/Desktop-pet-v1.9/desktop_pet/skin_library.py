from __future__ import annotations

import json
import shutil
import uuid
import zipfile
from pathlib import Path, PurePosixPath


class SkinLibrary:
    ALLOWED_PACKAGE_FILES = {"manifest.json", "spritesheet.png", "preview.png", "license.txt"}
    MAX_PACKAGE_BYTES = 100 * 1024 * 1024

    def __init__(self, project_dir: Path):
        self.project_dir = project_dir
        self.skins_dir = project_dir / "assets" / "skins"
        self.deleted_dir = project_dir / "assets" / "deleted_skins"
        self.skins_dir.mkdir(parents=True, exist_ok=True)

    def skin_dir(self, skin_id: str) -> Path:
        path = (self.skins_dir / skin_id).resolve()
        if path.parent != self.skins_dir.resolve():
            raise ValueError("无效的皮肤编号")
        return path

    def list_skins(self) -> list[dict]:
        result = []
        for folder in sorted((p for p in self.skins_dir.iterdir() if p.is_dir()), key=lambda p: p.name):
            data, error = self.read_manifest(folder.name)
            result.append({"id": folder.name, "name": str(data.get("name", folder.name)),
                           "builtin": folder.name == "pixelpaws", "error": error})
        return result

    def read_manifest(self, skin_id: str) -> tuple[dict, str | None]:
        try:
            data = json.loads((self.skin_dir(skin_id) / "manifest.json").read_text(encoding="utf-8"))
            if not isinstance(data, dict): raise ValueError("manifest.json 根节点必须是对象")
            return data, None
        except (OSError, ValueError) as exc:
            return {"name": skin_id}, str(exc)

    def display_name(self, skin_id: str) -> str:
        return str(self.read_manifest(skin_id)[0].get("name", skin_id))

    def quick_status(self, skin_id: str) -> str | None:
        """Cheap menu-time check; full frame validation happens when selected."""
        data, error = self.read_manifest(skin_id)
        if error:
            return error
        sheet = data.get("sheet", "spritesheet.png")
        if not isinstance(sheet, str) or not sheet or Path(sheet).name != sheet:
            return "精灵图文件名无效"
        if not (self.skin_dir(skin_id) / sheet).is_file():
            return f"找不到精灵图：{sheet}"
        return None

    def unique_name(self, wanted: str) -> str:
        names = {item["name"] for item in self.list_skins()}
        base = wanted.strip() or "未命名皮肤"
        if base not in names: return base
        index = 1
        while True:
            suffix = " - 副本" if index == 1 else f" - 副本 {index}"
            if base + suffix not in names:return base + suffix
            index += 1

    def new_id(self) -> str:
        return "skin_" + uuid.uuid4().hex[:12]

    def create_draft(self, name: str) -> str:
        skin_id = self.new_id(); folder = self.skin_dir(skin_id); folder.mkdir()
        data = {"format": "desktop-pet-skin", "formatVersion": 3,
                "name": self.unique_name(name), "sheet": "spritesheet.png",
                "requiredActions": {"idle": None, "walk": None, "pet": None, "drag": None},
                "animations": {}, "expressionMenu": []}
        (folder / "manifest.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return skin_id

    def delete_skin(self, skin_id: str, active_skin: str) -> None:
        if skin_id == active_skin: raise ValueError("当前正在使用的皮肤不能删除，请先切换皮肤")
        if skin_id == "pixelpaws": raise ValueError("内置 PixelPaws 皮肤不能删除")
        if len(self.list_skins()) <= 1: raise ValueError("至少需要保留一套皮肤")
        source = self.skin_dir(skin_id); self.deleted_dir.mkdir(parents=True, exist_ok=True)
        target = self.deleted_dir / skin_id
        if target.exists(): target = self.deleted_dir / f"{skin_id}_{uuid.uuid4().hex[:6]}"
        shutil.move(str(source), str(target))

    def import_package(self, package: Path, validator) -> str:
        if package.suffix.lower() not in (".dpskin", ".zip"):
            raise ValueError("请选择 .dpskin 或 .zip 皮肤包")
        temp_id = ".import_" + uuid.uuid4().hex; temp = self.skin_dir(temp_id); temp.mkdir()
        try:
            with zipfile.ZipFile(package, "r") as archive:
                files = [entry for entry in archive.infolist() if not entry.is_dir()]
                total = sum(entry.file_size for entry in files)
                if total > self.MAX_PACKAGE_BYTES: raise ValueError("皮肤包解压后超过100 MB限制")
                seen = set()
                for entry in files:
                    path = PurePosixPath(entry.filename.replace("\\", "/"))
                    if len(path.parts) != 1 or path.name.lower() not in self.ALLOWED_PACKAGE_FILES:
                        raise ValueError(f"皮肤包包含不允许的文件：{entry.filename}")
                    key = path.name.lower()
                    if key in seen: raise ValueError(f"皮肤包包含重复文件：{entry.filename}")
                    seen.add(key)
                    output_name = {"license.txt": "LICENSE.txt"}.get(key, key)
                    (temp / output_name).write_bytes(archive.read(entry))
                if not {"manifest.json", "spritesheet.png"}.issubset(seen):
                    raise ValueError("皮肤包必须包含 manifest.json 和 spritesheet.png")
            data = json.loads((temp / "manifest.json").read_text(encoding="utf-8"))
            if not isinstance(data, dict): raise ValueError("manifest.json 根节点必须是对象")
            data["name"] = self.unique_name(str(data.get("name", "导入的皮肤")))
            data["sheet"] = "spritesheet.png"
            (temp / "manifest.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            validator(temp)
            skin_id = self.new_id(); temp.replace(self.skin_dir(skin_id)); return skin_id
        except Exception:
            shutil.rmtree(temp, ignore_errors=True); raise

    def export_package(self, skin_id: str, destination: Path) -> None:
        folder = self.skin_dir(skin_id); required = folder / "manifest.json", folder / "spritesheet.png"
        if not all(path.exists() for path in required): raise ValueError("皮肤缺少配置文件或精灵图")
        with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name in ("manifest.json", "spritesheet.png", "preview.png", "LICENSE.txt"):
                path = folder / name
                if path.exists(): archive.write(path, arcname=name)
