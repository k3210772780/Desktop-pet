from __future__ import annotations

import json
import math
import shutil
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk


REQUIRED = (("idle", "待机"), ("walk", "移动"), ("pet", "点击"), ("drag", "拖拽"))
REQUIRED_IDS = {role: f"required_{index}" for index, (role, _) in enumerate(REQUIRED, 1)}


class SkinEditor(ttk.Frame):
    """Visual grid/action editor. Nothing is overwritten until Apply succeeds."""

    def __init__(self, master, asset_dir: Path, on_applied):
        super().__init__(master, padding=12)
        self.asset_dir, self.on_applied = asset_dir, on_applied
        self.source_path = asset_dir / "spritesheet.png"
        self.source = None
        self.actions = {}
        self.required_map = {role: None for role, _ in REQUIRED}
        self.expressions = []
        self.name_var = tk.StringVar(value="我的桌宠")
        self.info_var = tk.StringVar(value="尚未读取图片")
        self.rows_var, self.cols_var = tk.IntVar(value=1), tk.IntVar(value=1)
        self.facing_var = tk.StringVar(value="right")
        self.scale_var = tk.IntVar(value=50)
        self.render_size_var = tk.StringVar(value="请先设置有效网格")
        self.scale_var.trace_add("write",lambda *_:self._refresh_render_size())
        self.rows_var.trace_add("write",lambda *_:self._refresh_render_size())
        self.cols_var.trace_add("write",lambda *_:self._refresh_render_size())
        self._build()
        self._load_existing()

    def _build(self):
        top = ttk.LabelFrame(self, text="精灵图与裁切", padding=10)
        top.pack(fill="x")
        ttk.Button(top, text="选择精灵图…", command=self._choose_image).grid(row=0, column=0, padx=(0, 8))
        ttk.Label(top, textvariable=self.info_var).grid(row=0, column=1, columnspan=5, sticky="w")
        ttk.Label(top, text="皮肤名称").grid(row=1, column=0, sticky="e", pady=8)
        ttk.Entry(top, textvariable=self.name_var, width=22).grid(row=1, column=1, sticky="w")
        ttk.Label(top, text="列数").grid(row=1, column=2, sticky="e")
        ttk.Spinbox(top, from_=1, to=200, textvariable=self.cols_var, width=6).grid(row=1, column=3)
        ttk.Label(top, text="行数").grid(row=1, column=4, sticky="e")
        ttk.Spinbox(top, from_=1, to=200, textvariable=self.rows_var, width=6).grid(row=1, column=5)
        ttk.Label(top, text="素材默认朝向").grid(row=2, column=0, sticky="e")
        ttk.Radiobutton(top, text="向右", value="right", variable=self.facing_var).grid(row=2, column=1, sticky="w")
        ttk.Radiobutton(top, text="向左", value="left", variable=self.facing_var).grid(row=2, column=2, sticky="w")
        ttk.Button(top, text="查看裁切结果与序号", command=self._show_grid).grid(row=2, column=3, columnspan=3, sticky="e")
        ttk.Label(top, text="此皮肤显示缩放").grid(row=3, column=0, sticky="e", pady=(8,0))
        ttk.Spinbox(top, from_=10, to=200, textvariable=self.scale_var, width=8).grid(row=3, column=1, sticky="w", pady=(8,0))
        ttk.Label(top, text="%").grid(row=3, column=1, padx=(58,0), sticky="w", pady=(8,0))
        ttk.Label(top, textvariable=self.render_size_var, foreground="#555").grid(row=3, column=2, columnspan=4, sticky="w", pady=(8,0))

        required = ttk.LabelFrame(self, text="四个必要动作", padding=10)
        required.pack(fill="x", pady=10)
        self.required_labels = {}
        for row, (key, title) in enumerate(REQUIRED):
            ttk.Label(required, text=title, width=12).grid(row=row, column=0, sticky="w", pady=3)
            label = ttk.Label(required, text="未配置", width=42)
            label.grid(row=row, column=1, sticky="w")
            self.required_labels[key] = label
            ttk.Button(required, text="配置动作…", command=lambda k=key, t=title: self._edit_action(k, t)).grid(row=row, column=2)
            ttk.Button(required, text="预览", command=lambda k=key: self._preview_action(k)).grid(row=row, column=3, padx=(6,0))

        custom = ttk.LabelFrame(self, text="自定义表情（可不添加）", padding=10)
        custom.pack(fill="both", expand=True)
        ttk.Label(custom, text="示例：名称“开心”，帧序号 12,13,12,13，速度 5 FPS，持续 3 秒。",
                  foreground="#555").pack(anchor="w", pady=(0, 6))
        self.tree = ttk.Treeview(custom, columns=("frames", "fps", "duration"), show="tree headings", height=5)
        self.tree.heading("#0", text="菜单名称"); self.tree.column("#0", width=150)
        self.tree.heading("frames", text="帧播放顺序"); self.tree.column("frames", width=260)
        self.tree.heading("fps", text="FPS"); self.tree.column("fps", width=70)
        self.tree.heading("duration", text="持续时间"); self.tree.column("duration", width=90)
        self.tree.pack(fill="both", expand=True)
        buttons = ttk.Frame(custom); buttons.pack(fill="x", pady=(6, 0))
        ttk.Button(buttons, text="添加表情…", command=self._add_expression).pack(side="left")
        ttk.Button(buttons, text="编辑所选", command=self._edit_expression).pack(side="left", padx=6)
        ttk.Button(buttons, text="删除所选", command=self._delete_expression).pack(side="left")
        ttk.Button(buttons, text="预览所选动作", command=self._preview_selected).pack(side="right")

        bottom = ttk.Frame(self); bottom.pack(fill="x", pady=(10, 0))
        ttk.Button(bottom, text="检查并应用到当前桌宠", command=self.apply).pack(side="right")
        ttk.Label(bottom, text="应用前只在临时配置中修改；检查失败不会覆盖当前皮肤。",
                  foreground="#555").pack(side="left")

    def _load_existing(self):
        path = self.asset_dir / "manifest.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            self.name_var.set(str(data.get("name", "我的桌宠")))
            self.source_path = self.asset_dir / str(data.get("sheet", "spritesheet.png"))
            self.source = tk.PhotoImage(master=self, file=str(self.source_path))
            cw, ch = int(data["cropWidth"]), int(data["cropHeight"])
            self.cols_var.set(self.source.width() // cw); self.rows_var.set(self.source.height() // ch)
            self.facing_var.set(str(data.get("defaultFacing", "right")))
            self.scale_var.set(int(data.get("scalePercent", 50)))
            self.expressions = [dict(v) for v in data.get("expressionMenu", [])]
            raw_actions = data.get("animations", {})
            configured = data.get("requiredActions")
            self.required_map = dict(configured) if isinstance(configured, dict) else {role: None for role, _ in REQUIRED}
            retained = set(self.required_map.values()) | {item.get("action") for item in self.expressions}
            self.actions = {k: dict(v) for k, v in raw_actions.items() if k in retained}
            self._refresh_info(); self._refresh_actions(); self._refresh_tree()
        except (OSError, ValueError, KeyError, tk.TclError) as exc:
            self.info_var.set(f"现有皮肤读取失败：{exc}")

    def _choose_image(self):
        path = filedialog.askopenfilename(parent=self, title="选择 PNG 精灵图",
                                          filetypes=[("PNG 图片", "*.png"), ("所有文件", "*.*")])
        if not path: return
        try:
            image = tk.PhotoImage(master=self, file=path)
        except tk.TclError as exc:
            messagebox.showerror("无法读取图片", f"请选择有效的 PNG 图片。\n\n{exc}", parent=self); return
        self.source_path, self.source = Path(path), image
        self.actions = {}; self.required_map = {role: None for role, _ in REQUIRED}; self.expressions = []
        self._refresh_info(); self._refresh_actions(); self._refresh_tree()
        messagebox.showinfo("图片读取成功", f"图片像素：{image.width()} × {image.height()}\n请继续填写行数和列数。", parent=self)

    def _grid_values(self):
        if self.source is None: raise ValueError("请先选择精灵图")
        rows, cols = int(self.rows_var.get()), int(self.cols_var.get())
        if rows <= 0 or cols <= 0: raise ValueError("行数和列数必须大于0")
        width, height = self.source.width(), self.source.height()
        if width % cols: raise ValueError(f"图片宽度 {width} 不能被 {cols} 列整除")
        if height % rows: raise ValueError(f"图片高度 {height} 不能被 {rows} 行整除")
        return rows, cols, width // cols, height // rows

    def _refresh_info(self):
        if self.source:
            transparent="有透明像素" if self._has_transparency() else "未检测到透明像素"
            self.info_var.set(f"{self.source_path.name}　{self.source.width()} × {self.source.height()} 像素　{transparent}")
        self._refresh_render_size()

    def _refresh_render_size(self):
        try:
            _rows,_cols,cw,ch=self._grid_values(); scale=int(self.scale_var.get())
            self.render_size_var.set(f"单帧 {cw} × {ch} → 桌面约 {round(cw*scale/100)} × {round(ch*scale/100)} 像素")
        except (ValueError,tk.TclError):
            self.render_size_var.set("请先设置有效网格")

    def _has_transparency(self):
        if not self.source:return False
        step_x=max(1,self.source.width()//80); step_y=max(1,self.source.height()//80)
        try:
            return any(bool(int(self.source.tk.call(self.source,"transparency","get",x,y)))
                       for y in range(0,self.source.height(),step_y)
                       for x in range(0,self.source.width(),step_x))
        except tk.TclError:return False

    def _show_grid(self, selector=None):
        try: rows, cols, cw, ch = self._grid_values()
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("裁切设置有问题", str(exc), parent=self); return
        FrameGrid(self, self.source, rows, cols, cw, ch, selector)

    def _edit_action(self, role, title):
        action = self.required_map.get(role)
        initial = dict(self.actions.get(action, {"frames": [], "fps": 5, "loop": True}))
        ActionDialog(self, title, initial, lambda spec: self._save_action(role, spec), self._show_grid)

    def _save_action(self, role, spec):
        action = self.required_map.get(role) or REQUIRED_IDS[role]
        self.required_map[role] = action
        self.actions[action] = {k: spec[k] for k in ("frames", "fps", "loop")}
        self._refresh_actions()

    def _refresh_actions(self):
        for role, _ in REQUIRED:
            frames = self.actions.get(self.required_map.get(role), {}).get("frames", [])
            self.required_labels[role].configure(text=", ".join(map(str, frames)) if frames else "未配置")

    def _preview_action(self, role):
        spec = self.actions.get(self.required_map.get(role))
        if not spec or not spec.get("frames"):
            messagebox.showinfo("尚未配置", "请先配置这个动作的帧。", parent=self); return
        try:grid=self._grid_values()
        except (ValueError,tk.TclError) as exc:messagebox.showerror("无法预览",str(exc),parent=self);return
        PreviewWindow(self, self.source, grid, spec, self.facing_var.get(), self.scale_var.get())

    def _add_expression(self):
        ExpressionDialog(self, None, self._save_expression, self._show_grid)

    def _edit_expression(self):
        selected = self.tree.selection()
        if not selected: messagebox.showinfo("请选择表情", "请先在列表中选择一个表情。", parent=self); return
        item=dict(self.expressions[int(selected[0])]); item.update(self.actions.get(item["action"],{}))
        ExpressionDialog(self, item,
                         lambda item, i=int(selected[0]): self._save_expression(item, i), self._show_grid)

    def _save_expression(self, item, index=None):
        if any(other["name"] == item["name"] for i, other in enumerate(self.expressions) if i != index):
            messagebox.showerror("名称重复", f"已经存在名为“{item['name']}”的表情。", parent=self); return
        key = item["action"]
        if index is None: self.expressions.append(item)
        else:
            old_key=self.expressions[index]["action"]
            if old_key != key:self.actions.pop(old_key,None)
            self.expressions[index] = item
        self.actions[key] = {k: item[k] for k in ("frames", "fps", "loop")}
        self._refresh_tree()

    def _delete_expression(self):
        selected = self.tree.selection()
        if not selected: return
        index = int(selected[0]); item = self.expressions.pop(index)
        still_used=any(other["action"]==item["action"] for other in self.expressions)
        if item["action"] not in set(self.required_map.values()) and not still_used:self.actions.pop(item["action"], None)
        self._refresh_tree()

    def _refresh_tree(self):
        for item in self.tree.get_children(): self.tree.delete(item)
        for i, item in enumerate(self.expressions):
            spec = self.actions.get(item["action"], item)
            self.tree.insert("", "end", iid=str(i), text=item["name"],
                             values=(", ".join(map(str, spec.get("frames", []))), spec.get("fps", 5), item.get("duration", 3)))

    def _preview_selected(self):
        selected = self.tree.selection()
        if not selected: messagebox.showinfo("请选择动作", "请先选择一个自定义表情。", parent=self); return
        try:grid=self._grid_values()
        except (ValueError,tk.TclError) as exc:messagebox.showerror("无法预览",str(exc),parent=self);return
        item = self.expressions[int(selected[0])]; PreviewWindow(self, self.source, grid,
                                                                  self.actions[item["action"]], self.facing_var.get(), self.scale_var.get())

    def _validate(self):
        rows, cols, cw, ch = self._grid_values(); count = rows * cols
        missing = [title for role, title in REQUIRED
                   if not self.actions.get(self.required_map.get(role), {}).get("frames")]
        if missing: raise ValueError("以下必要动作尚未配置：" + "、".join(missing))
        for key, spec in self.actions.items():
            frames = spec.get("frames", [])
            if not frames or any(not isinstance(i, int) or not 0 <= i < count for i in frames):
                raise ValueError(f"动作 {key} 包含无效帧；有效序号为 0～{count-1}")
            if float(spec.get("fps", 0)) <= 0: raise ValueError(f"动作 {key} 的 FPS 必须大于0")
        scale = int(self.scale_var.get())
        if not 10 <= scale <= 200: raise ValueError("显示缩放必须在10%～200%之间")
        return rows, cols, cw, ch, scale

    def apply(self):
        try: rows, cols, cw, ch, scale = self._validate()
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror("暂时无法应用", str(exc), parent=self); return
        shown_w,shown_h=round(cw*scale/100),round(ch*scale/100)
        if max(shown_w,shown_h)>180 and not messagebox.askyesno(
                "显示尺寸较大",f"缩放后的单帧约为 {shown_w} × {shown_h} 像素，超过当前180 × 180桌宠窗口，部分内容可能被裁掉。\n\n仍然应用吗？",parent=self):return
        if not self._has_transparency() and not messagebox.askyesno(
                "未检测到透明背景","图片可能显示矩形底色。仍然应用吗？",parent=self):return
        expressions = []
        for item in self.expressions:
            expressions.append({"name": item["name"], "action": item["action"], "duration": float(item["duration"])})
        manifest = {"format": "desktop-pet-skin", "formatVersion": 3,
                    "name": self.name_var.get().strip() or "未命名皮肤", "sheet": "spritesheet.png",
                    "imageWidth": self.source.width(), "imageHeight": self.source.height(),
                    "cropWidth": cw, "cropHeight": ch, "columns": cols, "rows": rows,
                    "scalePercent": scale, "defaultFacing": self.facing_var.get(),
                    "requiredActions": self.required_map,
                    "animations": self.actions, "expressionMenu": expressions}
        old_image=old_manifest=None; target=self.asset_dir/"spritesheet.png"; old_manifest_path=self.asset_dir/"manifest.json"
        try:
            target = self.asset_dir / "spritesheet.png"; temp_json = self.asset_dir / "manifest.json.tmp"
            old_image = target.read_bytes() if target.exists() else None
            old_manifest = old_manifest_path.read_bytes() if old_manifest_path.exists() else None
            if self.source_path.resolve() != target.resolve(): shutil.copy2(self.source_path, target)
            temp_json.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            temp_json.replace(old_manifest_path)
            self.source_path = target
            self.on_applied()
        except (OSError, ValueError, tk.TclError) as exc:
            try:
                if old_image is not None:target.write_bytes(old_image)
                if old_manifest is not None:old_manifest_path.write_bytes(old_manifest)
            except OSError:pass
            messagebox.showerror("应用失败", f"已恢复修改前的皮肤。\n\n{exc}", parent=self); return
        messagebox.showinfo("应用成功", "新皮肤和动作配置已经应用到当前桌宠。", parent=self)


class FrameGrid(tk.Toplevel):
    def __init__(self, parent, source, rows, cols, cw, ch, selector=None):
        super().__init__(parent); self.title("裁切结果与帧序号"); self.attributes("-topmost", True)
        self.geometry("900x650"); self.images = []
        ttk.Label(self, text=f"保持原图结构：{rows} 行 × {cols} 列；帧序号从0开始。" +
                  (" 点击图片可添加到动作。" if selector else ""), padding=8).pack(anchor="w")
        canvas = tk.Canvas(self, highlightthickness=0); bar_y = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        bar_x = ttk.Scrollbar(self, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=bar_y.set, xscrollcommand=bar_x.set)
        bar_y.pack(side="right", fill="y"); bar_x.pack(side="bottom", fill="x"); canvas.pack(fill="both", expand=True)
        body = ttk.Frame(canvas); canvas.create_window((0, 0), window=body, anchor="nw")
        factor = max(1, math.ceil(max(cw / 120, ch / 100)))
        for row in range(rows):
            for col in range(cols):
                index = row * cols + col; frame = tk.PhotoImage(master=self, width=cw, height=ch)
                frame.tk.call(frame, "copy", source, "-from", col*cw, row*ch, (col+1)*cw, (row+1)*ch)
                thumb = frame.subsample(factor, factor); self.images.append(thumb)
                cell = ttk.Frame(body, padding=4); cell.grid(row=row, column=col, sticky="n")
                command = (lambda i=index: selector(i)) if selector else None
                ttk.Button(cell, image=thumb, command=command).pack()
                ttk.Label(cell, text=f"帧 {index}").pack()
        body.update_idletasks(); canvas.configure(scrollregion=canvas.bbox("all"))


class ActionDialog(tk.Toplevel):
    def __init__(self, parent, title, initial, on_save, show_grid):
        super().__init__(parent); self.title(f"配置动作：{title}"); self.attributes("-topmost", True); self.resizable(False, False)
        self.on_save, self.show_grid = on_save, show_grid
        self.frames = tk.StringVar(value=", ".join(map(str, initial.get("frames", []))))
        self.fps = tk.DoubleVar(value=initial.get("fps", 5)); self.loop = tk.BooleanVar(value=initial.get("loop", True))
        body = ttk.Frame(self, padding=14); body.pack()
        ttk.Label(body, text="帧播放顺序").grid(row=0, column=0, sticky="w")
        ttk.Entry(body, textvariable=self.frames, width=45).grid(row=1, column=0, columnspan=3, sticky="ew")
        ttk.Button(body, text="从裁切图添加…", command=lambda: show_grid(self._append_frame)).grid(row=2, column=0, sticky="w", pady=6)
        ttk.Button(body, text="清空", command=lambda: self.frames.set("")).grid(row=2, column=1)
        ttk.Label(body, text="FPS").grid(row=3, column=0, sticky="w")
        ttk.Spinbox(body, from_=0.1, to=60, increment=.5, textvariable=self.fps, width=8).grid(row=3, column=1, sticky="w")
        ttk.Checkbutton(body, text="循环播放", variable=self.loop).grid(row=4, column=0, sticky="w")
        ttk.Label(body, text="可重复选择同一帧，例如：12, 13, 12, 13", foreground="#555").grid(row=5, column=0, columnspan=3, sticky="w", pady=6)
        ttk.Button(body, text="保存", command=self._save).grid(row=6, column=1, pady=(8, 0))
        ttk.Button(body, text="取消", command=self.destroy).grid(row=6, column=2, pady=(8, 0))

    def _append_frame(self, index):
        current = self.frames.get().strip(); self.frames.set(f"{current}, {index}" if current else str(index))

    def _spec(self):
        try: frames = [int(v.strip()) for v in self.frames.get().split(",") if v.strip()]
        except ValueError: raise ValueError("帧序号只能填写整数，并使用逗号分隔")
        if not frames: raise ValueError("请至少选择一帧")
        if self.fps.get() <= 0: raise ValueError("FPS 必须大于0")
        return {"frames": frames, "fps": float(self.fps.get()), "loop": bool(self.loop.get())}

    def _save(self):
        try: spec = self._spec()
        except (ValueError, tk.TclError) as exc: messagebox.showerror("配置有问题", str(exc), parent=self); return
        self.on_save(spec); self.destroy()


class ExpressionDialog(ActionDialog):
    def __init__(self, parent, initial, on_save, show_grid):
        item = dict(initial or {}); super().__init__(parent, "自定义表情", item, lambda _: None, show_grid)
        self.name_var = tk.StringVar(value=item.get("name", "")); self.duration = tk.DoubleVar(value=item.get("duration", 3))
        self.on_expression_save = on_save; self.action_key=item.get("action")
        body = self.winfo_children()[0]
        ttk.Label(body, text="菜单名称").grid(row=6, column=0, sticky="w")
        ttk.Entry(body, textvariable=self.name_var, width=20).grid(row=6, column=1, columnspan=2, sticky="w")
        ttk.Label(body, text="持续秒数").grid(row=7, column=0, sticky="w")
        ttk.Spinbox(body, from_=.5, to=120, increment=.5, textvariable=self.duration, width=8).grid(row=7, column=1, sticky="w")
        for widget in body.grid_slaves(row=6):
            if isinstance(widget, ttk.Button): widget.grid_forget()
        ttk.Button(body, text="保存", command=self._save).grid(row=8, column=1, pady=(8, 0))
        ttk.Button(body, text="取消", command=self.destroy).grid(row=8, column=2, pady=(8, 0))

    def _save(self):
        try:
            spec = self._spec(); name = self.name_var.get().strip()
            if not name: raise ValueError("请填写表情名称")
            if self.duration.get() <= 0: raise ValueError("持续时间必须大于0")
        except (ValueError, tk.TclError) as exc: messagebox.showerror("配置有问题", str(exc), parent=self); return
        key = self.action_key or "custom_" + str(abs(hash(name)) % 100000000)
        self.on_expression_save({"name": name, "action": key, "duration": float(self.duration.get()), **spec})
        self.destroy()


class PreviewWindow(tk.Toplevel):
    def __init__(self, parent, source, grid, spec, default_facing, scale):
        super().__init__(parent); self.title("动作预览"); self.attributes("-topmost", True)
        _rows, cols, cw, ch = grid; self.frames = []
        for index in spec["frames"]:
            image = tk.PhotoImage(master=self, width=cw, height=ch); x, y = (index % cols)*cw, (index // cols)*ch
            image.tk.call(image, "copy", source, "-from", x, y, x+cw, y+ch)
            divisor=math.gcd(int(scale),100); self.frames.append(image.zoom(int(scale)//divisor,int(scale)//divisor).subsample(100//divisor,100//divisor))
        self.spec, self.default_facing, self.left = spec, default_facing, False; self.step = 0
        self.label = ttk.Label(self, padding=15); self.label.pack()
        controls = ttk.Frame(self); controls.pack(pady=(0, 10))
        ttk.Button(controls, text="切换左右方向", command=self._flip).pack(side="left")
        ttk.Button(controls, text="关闭", command=self.destroy).pack(side="left", padx=8)
        self.after(1, self._tick)

    def _flip(self): self.left = not self.left
    def _tick(self):
        if not self.winfo_exists() or not self.frames: return
        frame = self.frames[self.step % len(self.frames)]
        mirror = self.left != (self.default_facing == "left")
        shown = frame.subsample(-1, 1) if mirror else frame
        self.label.configure(image=shown); self.label.image = shown; self.step += 1
        self.after(max(20, int(1000 / float(self.spec.get("fps", 5)))), self._tick)
