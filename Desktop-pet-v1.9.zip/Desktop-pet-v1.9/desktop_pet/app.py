from __future__ import annotations

import math, random, time, tkinter as tk
from enum import Enum
from pathlib import Path
from tkinter import messagebox, ttk
from .config import load_config, save_config
from .skin_library import SkinLibrary
from .skin_management import SkinManagement
from .sprites import SpritePlayer
from .windows import (ActivityPoller, area_at, clamp_to_area, cursor_position,
                      monitor_work_areas, nearest_area, set_window_position)


class Mode(str, Enum):
    NORMAL = "NORMAL"
    DO_NOT_DISTURB = "DO_NOT_DISTURB"


class Behavior(str, Enum):
    IDLE="IDLE"; WALK="WALK"; CLICK="CLICK"; DRAG="DRAG"; EXPRESSION="EXPRESSION"


class DesktopPetApp:
    SIZE=180; TRANSPARENT="#ff00ff"

    def __init__(self):
        self.root=tk.Tk(); self.root.title("双屏桌宠 v1.8.8"); self.root.overrideredirect(True)
        self.root.attributes("-topmost",True); self.root.attributes("-transparentcolor",self.TRANSPARENT)
        self.root.configure(bg=self.TRANSPARENT); self.root.geometry(f"{self.SIZE}x{self.SIZE}+0+0")
        self.canvas=tk.Canvas(self.root,width=self.SIZE,height=self.SIZE,bg=self.TRANSPARENT,highlightthickness=0)
        self.canvas.pack(); self._last_drawn=object(); self.config=load_config()
        self.project_dir=Path(__file__).resolve().parent.parent; self.library=SkinLibrary(self.project_dir)
        self.active_skin=self.config.get("active_skin","pixelpaws")
        self.sprites=SpritePlayer(self.root,self.library.skin_dir(self.active_skin))
        if self.sprites.error and self.active_skin!="pixelpaws":
            self.active_skin="pixelpaws"; self.sprites=SpritePlayer(self.root,self.library.skin_dir(self.active_skin))
            self.config["active_skin"]=self.active_skin; save_config(self.config)
        self.activity=ActivityPoller(); self.areas=monitor_work_areas()
        self.mode=Mode.DO_NOT_DISTURB if self.config["do_not_disturb"] else Mode.NORMAL
        self.behavior=Behavior.IDLE; self.behavior_since=time.monotonic(); self.facing="right"; self.frame=0
        self.target=None; self.route=[]; self.drag_offset=None; self.drag_previous_x=None; self.drag_moved=False
        self.animation_override=None
        self.expression_until=0.
        self.bubble=None; self.bubble_timeout_id=None
        self.skin_errors={}
        self.root.bind("<ButtonPress-1>",self._left_press); self.root.bind("<B1-Motion>",self._drag_move)
        self.root.bind("<ButtonRelease-1>",self._drag_end); self.root.bind("<Button-3>",self._show_menu)
        self._build_menu(); self.root.after(120,self._initial_position); self.root.after(33,self._tick)
        self.root.after(3000,self._decide)

    def run(self): self.root.mainloop()

    def _build_menu(self):
        old=getattr(self,"menu",None)
        if old is not None:
            try:old.destroy()
            except tk.TclError:pass
        self.menu=tk.Menu(self.root,tearoff=False,postcommand=self._prepare_menu)
        self.menu.add_command(label="站岗",command=self._toggle_movement)
        self.menu.add_separator(); self.skin_menu=tk.Menu(self.menu,tearoff=False)
        self.skin_var=tk.StringVar(value=self.active_skin); self._populate_skin_menu()
        self.menu.add_cascade(label="选择皮肤",menu=self.skin_menu)
        self.expressions=tk.Menu(self.menu,tearoff=False,postcommand=self._prepare_expression_menu)
        self.expressions.add_command(label="停止当前动作 / 回到待机",command=self._return_to_idle)
        self.expressions.add_separator()
        if self.sprites.expression_menu:
            for item in self.sprites.expression_menu:
                self.expressions.add_command(
                    label=item["name"],
                    command=lambda a=item["action"],d=item["duration"]:self._play_expression(a,d))
        else:
            self.expressions.add_command(label="暂无自定义表情",state="disabled")
        self.menu.add_cascade(label="选择表情",menu=self.expressions)
        self.menu.add_separator(); self.dnd_var=tk.BooleanVar(value=self.mode==Mode.DO_NOT_DISTURB)
        self.menu.add_checkbutton(label="工作免打扰",variable=self.dnd_var,command=self._toggle_dnd)
        self.menu.add_command(label="设置…",command=self._settings_window); self.menu.add_separator()
        self.menu.add_command(label="退出",command=self.root.destroy)

    def _populate_skin_menu(self):
        for item in self.library.list_skins():
            error=self.skin_errors.get(item["id"]) or item["error"] or self.library.quick_status(item["id"])
            valid=error is None
            label=item["name"] if valid else f"⚠ {item['name']}（不可用）"
            self.skin_menu.add_radiobutton(label=label,value=item["id"],variable=self.skin_var,
                                           state="normal" if valid else "disabled",
                                           command=lambda sid=item["id"]:self._switch_skin(sid))

    def _prepare_menu(self):
        dnd=self.mode==Mode.DO_NOT_DISTURB
        locked=bool(self.config["position_locked"])
        self.menu.entryconfigure(0,label="巡逻" if locked else "站岗",state="normal")
        self.dnd_var.set(dnd)

    def _prepare_expression_menu(self):
        self.expressions.entryconfigure(0,state="normal" if self.behavior!=Behavior.IDLE else "disabled")

    def _toggle_movement(self):
        locked=not bool(self.config["position_locked"]); self.config["position_locked"]=locked
        if locked:self._set_behavior(Behavior.IDLE)
        save_config(self.config)

    def _switch_skin(self,skin_id):
        if skin_id==self.active_skin:return True
        if self.drag_offset:
            messagebox.showinfo("暂时不能切换","请先松开桌宠，再切换皮肤。",parent=self.root)
            self.skin_var.set(self.active_skin);return False
        candidate=SpritePlayer(self.root,self.library.skin_dir(skin_id))
        if candidate.error:
            self.skin_errors[skin_id]=candidate.error
            messagebox.showerror("皮肤切换失败",candidate.error,parent=self.root)
            self.skin_var.set(self.active_skin); self.root.after_idle(self._build_menu); return False
        self.skin_errors.pop(skin_id,None)
        self.sprites=candidate; self.active_skin=skin_id; self.config["active_skin"]=skin_id; save_config(self.config)
        self.animation_override=None; self._set_behavior(Behavior.IDLE); self._build_menu()
        return True

    def _set_behavior(self,b,keep=False):
        if b!=self.behavior: self.behavior=b; self.behavior_since=time.monotonic()
        if b!=Behavior.WALK:self.target=None; self.route=[]
        if not keep and b!=Behavior.EXPRESSION:self.animation_override=None

    def _initial_position(self):
        if self.areas:
            a=self.areas[0]
            self._move(a.center_x-self.SIZE//2,a.bottom-self.SIZE)
            if not self.config.get("screen_intro_shown",False):
                self.config["screen_intro_shown"]=True; save_config(self.config)
                self.root.after(350,lambda:self._show_bubble(message=f"已识别 {len(self.areas)} 块屏幕",duration=3000))
            if self.sprites.error:
                self.root.after(500,lambda:self._show_bubble(message=f"皮肤加载失败：{self.sprites.error}",duration=6000))
    def _position(self): return self.root.winfo_x(),self.root.winfo_y()
    def _move(self,x,y):
        set_window_position(self.root.winfo_id(),int(x),int(y),self.SIZE,self.SIZE)

    def _choose_walk(self):
        if self.mode!=Mode.NORMAL or self.config["position_locked"] or self.config["movement_mode"]!="random":return
        self.areas=monitor_work_areas() or self.areas; x,y=self._position()
        current=area_at(x+self.SIZE//2,y+self.SIZE//2,self.areas) or nearest_area(x,y,self.areas)
        neighbors=[item for direction in (-1,1) if (item:=self._horizontal_neighbor(current,direction))]
        target_area=random.choice(neighbors)[0] if neighbors and random.random()<.30 else current
        tx=random.randint(target_area.left,max(target_area.left,target_area.right-self.SIZE))
        ty=random.randint(target_area.top,max(target_area.top,target_area.bottom-self.SIZE))
        self._route_to(tx,ty,target_area)

    def _horizontal_neighbor(self,area,direction):
        for other in self.areas:
            touches=(other.right==area.left) if direction<0 else (other.left==area.right)
            top=max(area.top,other.top); bottom=min(area.bottom,other.bottom)
            if other!=area and touches and bottom-top>=self.SIZE:return other,top,bottom
        return None

    def _route_to(self,tx,ty,target_area):
        x,y=self._position(); current=area_at(x+self.SIZE//2,y+self.SIZE//2,self.areas) or nearest_area(x,y,self.areas)
        points=[]
        if target_area!=current:
            direction=1 if target_area.left==current.right else -1 if target_area.right==current.left else 0
            connection=self._horizontal_neighbor(current,direction) if direction else None
            if not connection or connection[0]!=target_area:return False
            _,top,bottom=connection; seam_y=min(max(y,top),bottom-self.SIZE)
            if direction>0:points.extend([(current.right-self.SIZE,seam_y),(target_area.left,seam_y)])
            else:points.extend([(current.left,seam_y),(target_area.right-self.SIZE,seam_y)])
        points.append(clamp_to_area(tx,ty,self.SIZE,self.SIZE,target_area))
        self.route=[(int(px),int(py)) for px,py in points]
        self._set_behavior(Behavior.WALK); self.target=self.route.pop(0); return True

    def _constrained_step(self,x,y,nx,ny):
        current=area_at(x+self.SIZE//2,y+self.SIZE//2,self.areas) or nearest_area(x,y,self.areas)
        ny=min(max(int(ny),current.top),current.bottom-self.SIZE); nx=int(nx)
        if nx>current.right-self.SIZE:
            connection=self._horizontal_neighbor(current,1)
            if connection:
                other,top,bottom=connection
                if top<=ny<=bottom-self.SIZE:return min(nx,other.right-self.SIZE),ny
            return current.right-self.SIZE,ny
        if nx<current.left:
            connection=self._horizontal_neighbor(current,-1)
            if connection:
                other,top,bottom=connection
                if top<=ny<=bottom-self.SIZE:return max(nx,other.left),ny
            return current.left,ny
        return nx,ny

    def _return_to_idle(self):
        self._set_behavior(Behavior.IDLE)

    def _play_expression(self,anim,duration):
        self.animation_override=anim; self.expression_until=time.monotonic()+duration
        self._set_behavior(Behavior.EXPRESSION,keep=True)

    def _toggle_dnd(self):
        enabled=bool(self.dnd_var.get())
        if enabled:
            self.mode=Mode.DO_NOT_DISTURB; self.animation_override=None
            self._set_behavior(Behavior.IDLE)
        else:
            self.mode=Mode.NORMAL; self.animation_override=None; self._set_behavior(Behavior.IDLE)
        self.config["do_not_disturb"]=enabled; save_config(self.config)

    def _decide(self):
        if self.mode!=Mode.NORMAL or self.behavior in (Behavior.WALK,Behavior.EXPRESSION) or self.drag_offset:pass
        elif not self.config["position_locked"] and self.config["movement_mode"]=="random" and random.random()<.48:self._choose_walk()
        else:self._set_behavior(Behavior.IDLE)
        self.root.after(3000,self._decide)

    def _tick(self):
        self.frame+=1; now=time.monotonic(); events=self.activity.poll()
        if self.mode!=Mode.NORMAL or self.behavior==Behavior.EXPRESSION or self.drag_offset:events=set()
        can_control=self.mode==Mode.NORMAL and not self.config["position_locked"] and not self.drag_offset and self.behavior!=Behavior.EXPRESSION
        if can_control and self.config["movement_mode"]=="arrow_keys":
            dx,dy=self.activity.arrow_direction()
            if dx or dy:self._move_by_arrow(dx,dy)
            elif self.behavior==Behavior.WALK:self._set_behavior(Behavior.IDLE)
        elif can_control and self.config["movement_mode"]=="follow_cursor" and "mouse" in events:self._follow_cursor()
        if self.behavior==Behavior.EXPRESSION and now>=self.expression_until:self._set_behavior(Behavior.IDLE)
        elif self.behavior==Behavior.CLICK and now-self.behavior_since>1:self._set_behavior(Behavior.IDLE)
        if self.behavior==Behavior.WALK and self.target and self.drag_offset is None:
            self._advance_route()
        self._draw(); self.root.after(33,self._tick)

    def _advance_route(self):
        x,y=self._position(); tx,ty=self.target; speed=int(self.config["walk_speed"]); dx=tx-x; dy=ty-y
        if abs(dx)>1:self.facing="right" if dx>0 else "left"
        distance=math.hypot(dx,dy)
        if distance<=speed:
            self._move(tx,ty)
            if self.route:self.target=self.route.pop(0)
            else:self._set_behavior(Behavior.IDLE)
            return
        nx=x+dx/distance*speed; ny=y+dy/distance*speed
        nx,ny=self._constrained_step(x,y,nx,ny)
        if int(nx)==x and int(ny)==y:self._set_behavior(Behavior.IDLE);return
        self._move(nx,ny)

    def _move_by_arrow(self,dx,dy):
        length=math.hypot(dx,dy)
        if not length:return
        speed=float(self.config["walk_speed"]); x,y=self._position()
        nx=x+dx/length*speed; ny=y+dy/length*speed
        nx,ny=self._constrained_step(x,y,nx,ny)
        if dx:self.facing="right" if dx>0 else "left"
        self._set_behavior(Behavior.WALK); self.target=None; self.route=[]; self._move(nx,ny)

    def _animation(self):
        if self.animation_override:return self.animation_override
        if self.behavior==Behavior.WALK:return self.sprites.action_for("walk")
        if self.behavior==Behavior.CLICK:return self.sprites.action_for("pet")
        if self.behavior==Behavior.DRAG:return self.sprites.action_for("drag")
        return self.sprites.action_for("idle")

    def _draw(self):
        img=self.sprites.frame(self._animation(),time.monotonic()-self.behavior_since,self.facing)
        if img is self._last_drawn:return
        self._last_drawn=img; self.canvas.delete("all")
        if img is not None:self.canvas.create_image(self.SIZE//2,self.SIZE,image=img,anchor="s"); return
        b=0; c=self.canvas
        c.create_oval(59,48+b,82,76+b,fill="#8bd3dd"); c.create_oval(98,48+b,121,76+b,fill="#8bd3dd")
        c.create_oval(52,62+b,128,132+b,fill="#8bd3dd",outline="#29303b",width=3)

    def _follow_cursor(self):
        if self.mode!=Mode.NORMAL:return
        cx,cy=cursor_position(); a=area_at(cx,cy,self.areas) or nearest_area(cx,cy,self.areas)
        tx,ty=clamp_to_area(cx-self.SIZE//2+55,cy-self.SIZE//2+55,self.SIZE,self.SIZE,a)
        if not self._route_to(tx,ty,a):self._set_behavior(Behavior.IDLE)
    def _left_press(self,e):
        self.drag_offset=(e.x,e.y); self.drag_previous_x=e.x_root; self.drag_moved=False
    def _drag_move(self,e):
        if self.drag_offset:
            if self.config["position_locked"]:return
            if not self.drag_moved and (abs(e.x-self.drag_offset[0])>=3 or abs(e.y-self.drag_offset[1])>=3):
                self.drag_moved=True; self._set_behavior(Behavior.DRAG)
            if not self.drag_moved:return
            if self.drag_previous_x is not None and abs(e.x_root-self.drag_previous_x)>=3:self.facing="right" if e.x_root>self.drag_previous_x else "left"
            self.drag_previous_x=e.x_root
            a=area_at(e.x_root,e.y_root,self.areas) or nearest_area(e.x_root,e.y_root,self.areas)
            x,y=clamp_to_area(e.x_root-self.drag_offset[0],e.y_root-self.drag_offset[1],self.SIZE,self.SIZE,a)
            self._move(x,y)
    def _drag_end(self,e):
        if not self.drag_offset:return
        was_dragged=self.drag_moved
        self.drag_offset=None; self.drag_previous_x=None; x,y=self._position(); a=nearest_area(x+self.SIZE//2,y+self.SIZE//2,self.areas)
        x,y=clamp_to_area(x,y,self.SIZE,self.SIZE,a); self._move(x,y)
        if self.mode==Mode.DO_NOT_DISTURB:self._set_behavior(Behavior.IDLE)
        elif was_dragged:self._set_behavior(Behavior.IDLE)
        else:self._set_behavior(Behavior.CLICK)
        self.drag_moved=False
    def _show_menu(self,e):self.menu.tk_popup(e.x_root,e.y_root)
    def _show_bubble(self,message,duration=2200):
        self._hide_bubble(); self.bubble=tk.Toplevel(self.root); self.bubble.overrideredirect(True); self.bubble.attributes("-topmost",True)
        tk.Label(self.bubble,text=message,bg="#20242c",fg="white",padx=12,pady=8).pack()
        self.bubble.update_idletasks(); x,y=self._position(); bw=self.bubble.winfo_reqwidth(); bh=self.bubble.winfo_reqheight()
        bx=x+(self.SIZE-bw)//2; by=y-bh-8
        a=nearest_area(x+self.SIZE//2,y+self.SIZE//2,self.areas)
        bx=min(max(bx,a.left),a.right-bw); by=min(max(by,a.top),a.bottom-bh)
        set_window_position(self.bubble.winfo_id(),bx,by,bw,bh)
        self.bubble_timeout_id=self.root.after(duration,self._hide_bubble)
    def _hide_bubble(self):
        if self.bubble_timeout_id is not None:
            try:self.root.after_cancel(self.bubble_timeout_id)
            except tk.TclError:pass
            self.bubble_timeout_id=None
        if self.bubble:self.bubble.destroy(); self.bubble=None
    def _settings_window(self):
        existing=getattr(self,"settings_window",None)
        if existing and existing.winfo_exists():
            existing.lift()
            return
        w=tk.Toplevel(self.root); self.settings_window=w; w.title("桌宠设置 v1.8.8")
        w.geometry("1120x760"); notebook=ttk.Notebook(w); self.settings_notebook=notebook; notebook.pack(fill="both",expand=True)
        body=ttk.Frame(notebook,padding=18); notebook.add(body,text="基础设置")
        movement_mode=tk.StringVar(value=self.config["movement_mode"])
        speed=tk.IntVar(value=self.config["walk_speed"]); dnd=tk.BooleanVar(value=self.mode==Mode.DO_NOT_DISTURB)
        modes=ttk.LabelFrame(body,text="移动控制方式",padding=10); modes.grid(row=0,column=0,columnspan=2,sticky="ew",pady=(0,10))
        ttk.Radiobutton(modes,text="自主随机移动",value="random",variable=movement_mode).pack(anchor="w")
        ttk.Radiobutton(modes,text="跟随鼠标位置",value="follow_cursor",variable=movement_mode).pack(anchor="w",pady=4)
        ttk.Radiobutton(modes,text="方向键控制（↑ ↓ ← →）",value="arrow_keys",variable=movement_mode).pack(anchor="w")
        ttk.Label(body,text="移动速度").grid(row=1,column=0,sticky="w")
        ttk.Scale(body,from_=2,to=10,variable=speed).grid(row=1,column=1,sticky="ew")
        ttk.Checkbutton(body,text="启动后保持工作免打扰",variable=dnd).grid(row=2,column=0,columnspan=2,sticky="w",pady=6)
        body.columnconfigure(1,weight=1)
        def save():
            self.config.update(movement_mode=movement_mode.get(),walk_speed=speed.get()); save_config(self.config); self._set_behavior(Behavior.IDLE); w.destroy()
            if dnd.get()!=(self.mode==Mode.DO_NOT_DISTURB):self.dnd_var.set(dnd.get()); self._toggle_dnd()
        ttk.Button(body,text="保存基础设置",command=save).grid(row=3,column=0,pady=18,sticky="w")
        ttk.Button(body,text="关闭",command=w.destroy).grid(row=3,column=1,pady=18,sticky="w")
        skin=ttk.Frame(notebook); notebook.add(skin,text="皮肤与动作")
        self.skin_management=None
        def ensure_skin_management():
            if self.skin_management is None or not self.skin_management.winfo_exists():
                self.skin_management=SkinManagement(
                    skin,self.library,lambda:self.active_skin,self._switch_skin,self._reload_skin)
                self.skin_management.pack(fill="both",expand=True)
        selected=self.config.get("settings_tab","basic")
        notebook.select(skin if selected=="skins" else body)
        def remember_tab(_event=None):
            on_skins=notebook.select()==str(skin)
            self.config["settings_tab"]="skins" if on_skins else "basic"
            save_config(self.config)
            if on_skins:ensure_skin_management()
        notebook.bind("<<NotebookTabChanged>>",remember_tab)
        if selected=="skins":ensure_skin_management()
        w.after_idle(w.lift)

    def _reload_skin(self,skin_id=None):
        skin_id=skin_id or self.active_skin
        replacement=SpritePlayer(self.root,self.library.skin_dir(skin_id))
        if replacement.error:raise ValueError(replacement.error)
        self.skin_errors.pop(skin_id,None)
        if skin_id==self.active_skin:
            self.sprites=replacement; self._build_menu(); self._set_behavior(Behavior.IDLE)
