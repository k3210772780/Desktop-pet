from __future__ import annotations

import json
import math
from pathlib import Path
import tkinter as tk


class SpritePlayer:
    """Standard-library-only sprite sheet loader using Tk's native image engine."""

    REQUIRED_ROLES = ("idle", "walk", "pet", "drag")

    def __init__(self, master: tk.Misc, asset_dir: Path | None = None):
        self.asset_dir = asset_dir or Path(__file__).resolve().parent.parent / "assets" / "skins" / "pixelpaws"
        self.available = False
        self.frames: dict[int, tk.PhotoImage] = {}
        self.mirrored_frames: dict[int, tk.PhotoImage] = {}
        self.animations = {}
        self.required_actions = {}
        self.expression_menu = []
        self.skin_name = ""
        self.default_facing = "right"
        self.error = None
        self._source = None
        manifest_path = self.asset_dir / "manifest.json"
        if not manifest_path.exists():
            self.error = "找不到 manifest.json"
            return
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.skin_name = str(manifest.get("name", "未命名皮肤"))
            sheet_path = self.asset_dir / str(manifest["sheet"])
            if not sheet_path.exists():
                raise ValueError(f"找不到皮肤图片：{sheet_path.name}")
            self.animations = manifest["animations"]
            self.required_actions = manifest.get("requiredActions", {})
            self.expression_menu = self._validate_expression_menu(manifest.get("expressionMenu", []))
            self._source = tk.PhotoImage(master=master, file=str(sheet_path))
            image_w, image_h = int(manifest["imageWidth"]), int(manifest["imageHeight"])
            cell_w, cell_h = int(manifest["cropWidth"]), int(manifest["cropHeight"])
            scale = int(manifest["scalePercent"])
            self.default_facing = str(manifest.get("defaultFacing", "right"))
            if self.default_facing not in ("left", "right"):
                raise ValueError("defaultFacing 只能是 left 或 right")
            if min(image_w, image_h, cell_w, cell_h, scale) <= 0:
                raise ValueError("图片、裁剪尺寸和显示缩放必须为正数")
            if self._source.width() != image_w or self._source.height() != image_h:
                raise ValueError(
                    f"图片实际尺寸 {self._source.width()}x{self._source.height()} "
                    f"与 JSON 声明 {image_w}x{image_h} 不一致")
            if image_w % cell_w or image_h % cell_h:
                raise ValueError("图片宽高必须能被单帧裁剪宽高整除")
            columns, rows = image_w // cell_w, image_h // cell_h
            frame_count = columns * rows
            self._validate_animations(frame_count)
            divisor = math.gcd(scale, 100); zoom, shrink = scale // divisor, 100 // divisor
            indices = {i for spec in self.animations.values() for i in spec["frames"]}
            for index in indices:
                x, y = (index % columns) * cell_w, (index // columns) * cell_h
                frame = tk.PhotoImage(master=master, width=cell_w, height=cell_h)
                frame.tk.call(frame, "copy", self._source, "-from", x, y, x + cell_w, y + cell_h)
                rendered = frame.zoom(zoom, zoom).subsample(shrink, shrink)
                mirrored = frame.zoom(zoom, zoom).subsample(-shrink, shrink)
                if self.default_facing == "left": rendered, mirrored = mirrored, rendered
                self.frames[index] = rendered
                self.mirrored_frames[index] = mirrored
            self.available = bool(self.frames)
        except (KeyError, OSError, TypeError, ValueError, tk.TclError) as exc:
            self.error = str(exc)
            self.available = False
            self.expression_menu = []
            self.frames.clear()
            self.mirrored_frames.clear()

    def _validate_animations(self, frame_count: int) -> None:
        if not isinstance(self.animations, dict) or not self.animations:
            raise ValueError("animations 必须包含至少一个动作")
        if not isinstance(self.required_actions, dict):
            raise ValueError("requiredActions 必须是对象")
        missing = [role for role in self.REQUIRED_ROLES
                   if not self.required_actions.get(role)
                   or self.required_actions.get(role) not in self.animations]
        if missing:
            raise ValueError("缺少必要动作职责：" + ", ".join(missing))
        for action, spec in self.animations.items():
            frames = spec.get("frames") if isinstance(spec, dict) else None
            if not isinstance(frames, list) or not frames:
                raise ValueError(f"动作 {action} 没有有效帧列表")
            if any(not isinstance(i, int) or i < 0 or i >= frame_count for i in frames):
                raise ValueError(f"动作 {action} 使用了超出图片范围的帧")
            if float(spec.get("fps", 0)) <= 0:
                raise ValueError(f"动作 {action} 的 fps 必须大于 0")

    def _validate_expression_menu(self, items) -> list[dict]:
        if not isinstance(items, list):
            raise ValueError("expressionMenu 必须是列表")
        result = []
        for item in items:
            if not isinstance(item, dict):
                raise ValueError("expressionMenu 的每一项必须是对象")
            name, action = str(item.get("name", "")).strip(), str(item.get("action", "")).strip()
            duration = float(item.get("duration", 3.0))
            if not name or action not in self.animations or duration <= 0:
                raise ValueError(f"无效的表情菜单项：{item}")
            result.append({"name": name, "action": action, "duration": duration})
        return result

    def action_for(self, role: str) -> str | None:
        """Resolve an event role only through the skin's explicit settings."""
        action = self.required_actions.get(role)
        return action if action in self.animations else None

    def _animation_spec(self, animation: str | None):
        return self.animations.get(animation) if animation else None

    def frame(self, animation: str, elapsed: float, facing: str = "right") -> tk.PhotoImage | None:
        spec = self._animation_spec(animation)
        if not self.available or not spec:
            return None
        sequence = spec["frames"]
        offset = int(elapsed * float(spec["fps"]))
        if spec.get("loop", True):
            offset %= len(sequence)
        else:
            offset = min(offset, len(sequence) - 1)
        bank = self.mirrored_frames if facing == "left" else self.frames
        return bank.get(sequence[offset])
