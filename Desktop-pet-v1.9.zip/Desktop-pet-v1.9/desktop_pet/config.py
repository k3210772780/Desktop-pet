from __future__ import annotations

import json
from pathlib import Path


DEFAULTS = {
    "movement_mode": "random",
    "walk_speed": 5,
    "position_locked": False,
    "active_skin": "pixelpaws",
    "do_not_disturb": False,
    "screen_intro_shown": False,
    "settings_tab": "basic",
}
CONFIG_PATH = Path(__file__).resolve().parent.parent / "settings.json"


def load_config() -> dict:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    clean = {**DEFAULTS, **{k: data[k] for k in DEFAULTS if k in data}}
    if clean["movement_mode"] not in ("random", "follow_cursor", "arrow_keys"):
        clean["movement_mode"] = "random"
    if clean["settings_tab"] not in ("basic", "skins"):
        clean["settings_tab"] = "basic"
    return clean


def save_config(config: dict) -> None:
    clean = {k: config.get(k, value) for k, value in DEFAULTS.items()}
    CONFIG_PATH.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
