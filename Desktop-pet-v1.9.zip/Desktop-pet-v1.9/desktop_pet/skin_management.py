from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from .skin_editor import SkinEditor
from .sprites import SpritePlayer


class SkinManagement(ttk.Frame):
    def __init__(self, master, library, active_getter, on_switch, on_active_applied):
        super().__init__(master, padding=8)
        self.library, self.active_getter = library, active_getter
        self.on_switch, self.on_active_applied = on_switch, on_active_applied
        self.ids = []; self.editor = None
        self._build(); self.refresh(select_id=active_getter())

    def _build(self):
        pane = ttk.Panedwindow(self, orient="horizontal"); pane.pack(fill="both", expand=True)
        left = ttk.Frame(pane, padding=6); self.right = ttk.Frame(pane)
        pane.add(left, weight=0); pane.add(self.right, weight=1)
        ttk.Label(left, text="皮肤列表", font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", pady=(0,6))
        self.listbox = tk.Listbox(left, width=25, height=22, exportselection=False)
        self.listbox.pack(fill="y", expand=True); self.listbox.bind("<<ListboxSelect>>", self._selection_changed)
        ttk.Button(left, text="设为当前皮肤", command=self._activate).pack(fill="x", pady=(8,4))
        ttk.Button(left, text="新建空白皮肤…", command=self._new).pack(fill="x")
        ttk.Button(left, text="安全删除", command=self._delete).pack(fill="x", pady=4)
        ttk.Separator(left).pack(fill="x", pady=7)
        ttk.Button(left, text="导入 .dpskin / .zip…", command=self._import).pack(fill="x")
        ttk.Button(left, text="导出所选 .dpskin…", command=self._export).pack(fill="x", pady=4)

    def selected_id(self):
        selected = self.listbox.curselection()
        return self.ids[selected[0]] if selected else None

    def refresh(self, select_id=None):
        self.listbox.delete(0, "end"); self.ids=[]; active=self.active_getter()
        for item in self.library.list_skins():
            validation=SpritePlayer(self,self.library.skin_dir(item["id"])).error
            self.ids.append(item["id"]); prefix="● " if item["id"]==active else "  "
            suffix="（配置有误）" if item["error"] or validation else ""
            self.listbox.insert("end",prefix+item["name"]+suffix)
        wanted=select_id if select_id in self.ids else active if active in self.ids else (self.ids[0] if self.ids else None)
        if wanted:
            index=self.ids.index(wanted); self.listbox.selection_set(index); self.listbox.see(index); self._open_editor(wanted)

    def _selection_changed(self, _event=None):
        skin_id=self.selected_id()
        if skin_id:self._open_editor(skin_id)

    def _open_editor(self, skin_id):
        if self.editor is not None:
            try:self.editor.destroy()
            except tk.TclError:pass
        self.editor=SkinEditor(self.right,self.library.skin_dir(skin_id),
                               lambda sid=skin_id:self._applied(sid))
        self.editor.pack(fill="both",expand=True)

    def _applied(self, skin_id):
        if skin_id==self.active_getter():self.on_active_applied(skin_id)
        self.after(100,lambda:self.refresh(select_id=skin_id))

    def _activate(self):
        skin_id=self.selected_id()
        if not skin_id:return
        if self.on_switch(skin_id):self.refresh(select_id=skin_id)

    def _new(self):
        name=simpledialog.askstring("新建空白皮肤","请输入皮肤名称：",parent=self)
        if name is None:return
        skin_id=self.library.create_draft(name); self.refresh(select_id=skin_id)
        messagebox.showinfo("空白皮肤已创建","请选择精灵图，然后配置四个必要动作。配置完整前不会出现在可切换皮肤中。",parent=self)

    def _delete(self):
        skin_id=self.selected_id()
        if not skin_id:return
        name=self.library.display_name(skin_id)
        if not messagebox.askyesno("安全删除皮肤",f"将“{name}”移动到 assets/deleted_skins，确认继续吗？",parent=self):return
        try:self.library.delete_skin(skin_id,self.active_getter())
        except ValueError as exc:messagebox.showerror("不能删除",str(exc),parent=self);return
        self.refresh()

    def _validate_dir(self, folder: Path):
        player=SpritePlayer(self,folder)
        if player.error:raise ValueError(player.error)

    def _import(self):
        path=filedialog.askopenfilename(parent=self,title="导入完整皮肤包",
                                        filetypes=[("桌宠皮肤包","*.dpskin *.zip"),("所有文件","*.*")])
        if not path:return
        try:skin_id=self.library.import_package(Path(path),self._validate_dir)
        except (OSError,ValueError,tk.TclError) as exc:messagebox.showerror("导入失败",str(exc),parent=self);return
        self.refresh(select_id=skin_id)
        if messagebox.askyesno("导入成功",f"皮肤“{self.library.display_name(skin_id)}”已导入。是否立即使用？",parent=self):
            self._activate()

    def _export(self):
        skin_id=self.selected_id()
        if not skin_id:return
        try:self._validate_dir(self.library.skin_dir(skin_id))
        except (ValueError,tk.TclError) as exc:messagebox.showerror("暂时不能导出",str(exc),parent=self);return
        name=self.library.display_name(skin_id).replace("/","_").replace("\\","_")
        path=filedialog.asksaveasfilename(parent=self,title="导出完整皮肤包",initialfile=name+".dpskin",
                                          defaultextension=".dpskin",filetypes=[("桌宠皮肤包","*.dpskin")])
        if not path:return
        try:self.library.export_package(skin_id,Path(path))
        except (OSError,ValueError) as exc:messagebox.showerror("导出失败",str(exc),parent=self);return
        messagebox.showinfo("导出成功",f"完整皮肤包已保存：\n{path}",parent=self)
