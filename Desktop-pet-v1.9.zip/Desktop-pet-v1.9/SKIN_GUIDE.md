# v1.8.8 皮肤与动作配置说明

推荐直接在桌宠上右键打开“设置…”，进入“皮肤与动作”页面完成图片读取、网格裁切、动作配置和预览，不再需要手写 JSON。

每套皮肤使用独立目录：

```text
assets/skins/皮肤编号/
├─ spritesheet.png
└─ manifest.json
```

推荐通过设置界面读取图片并保存动作；检查通过后会立即更新对应皮肤。也可以按此目录结构手动维护高级配置。

## 完整皮肤包

设置界面可以导出 `皮肤名称.dpskin`。它是使用 Deflate 压缩的标准 ZIP，根目录结构为：

```text
manifest.json
spritesheet.png
preview.png     可选
LICENSE.txt     可选
```

导入同时接受 `.dpskin` 和 `.zip`。包内不能额外嵌套文件夹，也不能包含 Python、BAT、EXE 或其他程序文件。导入前会检查图片、四项必要动作、帧范围和表情引用；同名皮肤自动作为副本导入，不覆盖已有皮肤。

v1.8.8 使用皮肤格式版本3。四个必要职责是待机、移动、点击和拖拽；缺少任何一项的皮肤会标记为配置不完整，在设置中补全并重新应用后即可使用。

## 基本尺寸

```json
{
  "name": "我的皮肤",
  "sheet": "spritesheet.png",
  "imageWidth": 840,
  "imageHeight": 3300,
  "cropWidth": 210,
  "cropHeight": 300,
  "scalePercent": 50,
  "defaultFacing": "right"
}
```

- `imageWidth`、`imageHeight`：PNG原图的实际宽高。
- `cropWidth`、`cropHeight`：每个动作帧的裁剪宽高。
- 程序自动计算列数和行数，图片宽高必须能被裁剪宽高整除。
- `scalePercent`：当前这套皮肤自己的桌宠显示缩放百分比，在皮肤列表右侧的编辑区域调整。
- `defaultFacing`：精灵图素材原本朝向，可在裁切区域选择向左或向右。
- 缩小后的单帧建议不要超过180×180，否则超出桌宠窗口的部分会被裁掉。
- PNG应带透明通道，所有格子尺寸必须一致，角色尽量底部对齐。

帧编号从左到右、从上到下，从0开始：

```text
0  1  2  3
4  5  6  7
8  9  10 11
```

## 定义动作

```json
"animations": {
  "action_001": {"frames": [0, 1], "fps": 2, "loop": true},
  "action_002": {"frames": [4, 5, 6, 7], "fps": 10, "loop": true},
  "custom_001": {"frames": [12, 13], "fps": 5, "loop": true}
}
```

- 动作键（如 `action_001`）只是内部编号，本身不会触发任何行为。
- `frames`是播放顺序，可以重复帧。
- `fps`是每秒帧数，必须大于0。
- `loop`决定是否循环；非循环动作停在最后一帧，直到动作时间结束。

每套皮肤必须为以下四种基础职责指定动作：

```text
idle walk pet drag
```

它们分别对应待机、移动、用户点击桌宠和鼠标拖拽桌宠。动作本身可以使用任意内部编号，通过 `requiredActions` 建立映射：

```json
"requiredActions": {
  "idle": "required_1",
  "walk": "required_2",
  "pet": "required_3",
  "drag": "required_4"
}
```

程序只读取这四项映射，不根据动作英文名称猜测用途。缺少任意一项时，皮肤配置会被判定为不完整。

选择一张新精灵图后，四项映射和自定义表情默认全部为空。除了四个必要动作，其余都作为“自定义表情”管理。用户可以按需要添加任意数量，也可以完全不添加；只有四个必要动作时桌宠仍能正常运行。程序不会自动触发睡觉、醒来、快速输入、拖动、鼠标观察或免打扰专属动作。

素材原始朝向在裁切区域选择，程序会自动生成相反方向的水平镜像。

## 定义右键表情菜单

```json
"expressionMenu": [
  {"name": "开心", "action": "happy", "duration": 3.0},
  {"name": "打哈欠", "action": "yawn", "duration": 2.5}
]
```

- `name`：右键菜单中显示的文字，可以使用中文或其他语言。
- `action`：必须与 `animations` 中的动作键完全一致。
- `duration`：该表情播放多少秒，必须大于0。
- 菜单顺序与数组顺序一致。
- 可以增加、删除或重排任意表情，不需要修改程序。

如果 `expressionMenu` 是空数组，右键“选择表情”中会显示“暂无可用表情”。

## 完整最小示例

```json
{
  "format": "desktop-pet-skin",
  "formatVersion": 3,
  "name": "四动作小猫",
  "sheet": "spritesheet.png",
  "imageWidth": 1024,
  "imageHeight": 128,
  "cropWidth": 128,
  "cropHeight": 128,
  "scalePercent": 100,
  "defaultFacing": "right",
  "requiredActions": {
    "idle": "required_1",
    "walk": "required_2",
    "pet": "required_3",
    "drag": "required_4"
  },
  "animations": {
    "required_1": {"frames": [0, 1], "fps": 2, "loop": true},
    "required_2": {"frames": [2, 3], "fps": 8, "loop": true},
    "required_3": {"frames": [4, 5], "fps": 6, "loop": false},
    "required_4": {"frames": [6, 7], "fps": 6, "loop": true}
  },
  "expressionMenu": [
    {"name": "回应我", "action": "required_3", "duration": 3.0}
  ]
}
```

启动时程序会检查：图片实际尺寸、网格是否能整除、帧是否越界、动作速度以及菜单动作是否存在。配置错误时会显示“皮肤加载失败”，并安全回退到占位图形。
