from enum import Enum


class Mode(str, Enum):
    NORMAL = "NORMAL"
    DO_NOT_DISTURB = "DO_NOT_DISTURB"


class Behavior(str, Enum):
    IDLE = "IDLE"
    WALK = "WALK"
    TYPING = "TYPING"
    CLICK = "CLICK"
    DRAG = "DRAG"
    SLEEP = "SLEEP"
    WAKE = "WAKE"
    EXPRESSION = "EXPRESSION"
    CROUCH = "CROUCH"
    PHYSICS = "PHYSICS"
    SIDEREST = "SIDEREST"
