import time
import tkinter as tk
from tkinter import messagebox

from .config import save_config
from .models import Behavior, Mode
from .windows import area_at, clamp_to_area, nearest_area, set_window_position


class UserInterfaceMixin:
    """Context menu, pointer interaction, status bubbles, and information dialogs."""

    def _build_menu(self):
        old_menu = getattr(self, "menu", None)
        if old_menu is not None:
            try:
                old_menu.destroy()
            except tk.TclError:
                pass

        self.menu = tk.Menu(self.root, tearoff=False, postcommand=self._prepare_menu)
        self.menu.add_command(label="站岗", command=self._toggle_lock)
        self.menu.add_separator()
        self._build_expression_menu()
        self.menu.add_separator()

        self.agent_var = tk.BooleanVar(value=self.agent.enabled)
        self.menu.add_checkbutton(
            label="智能陪伴",
            variable=self.agent_var,
            command=self._toggle_agent,
        )
        self.menu.add_command(label="今日状态…", command=self._show_agent_status)
        self._build_reminder_menu()

        self.dnd_var = tk.BooleanVar(value=self.mode == Mode.DO_NOT_DISTURB)
        self.menu.add_checkbutton(
            label="工作免打扰",
            variable=self.dnd_var,
            command=self._toggle_dnd,
        )
        self.menu.add_separator()
        self.menu.add_command(label="设置…", command=self._settings_window)
        self.menu.add_command(label="关于…", command=self._about_window)
        self.menu.add_separator()
        self.menu.add_command(label="退出", command=self._exit_app)

    def _build_expression_menu(self):
        self.expressions = tk.Menu(
            self.menu,
            tearoff=False,
            postcommand=self._prepare_expression_menu,
        )
        self.expressions.add_command(
            label="停止当前动作 / 回到待机",
            command=self._return_to_idle,
        )
        self.expressions.add_separator()
        self.expression_actions = []
        for item in self.sprites.expression_menu:
            self.expression_actions.append(item["action"])
            self.expressions.add_command(
                label=item["name"],
                command=lambda action=item["action"], duration=item["duration"]: (
                    self._request_expression(action, duration)
                ),
            )
        self.menu.add_cascade(label="选择表情", menu=self.expressions)

    def _build_reminder_menu(self):
        self.reminders = tk.Menu(self.menu, tearoff=False)
        for minutes in (25, 45, 60):
            self.reminders.add_command(
                label=f"{minutes}分钟后提醒",
                command=lambda value=minutes: self._set_local_reminder(value),
            )
        self.reminders.add_separator()
        self.reminders.add_command(label="自定义…", command=self._custom_reminder)
        self.reminders.add_command(label="取消当前提醒", command=self._cancel_local_reminder)
        self.menu.add_cascade(label="休息提醒", menu=self.reminders)

    def _prepare_menu(self):
        locked = bool(self.config["position_locked"])
        self.menu.entryconfigure(0, label="巡逻" if locked else "站岗", state="normal")
        self.agent_var.set(self.agent.enabled)
        self.dnd_var.set(self.mode == Mode.DO_NOT_DISTURB)

    def _prepare_expression_menu(self):
        state = "disabled" if self.behavior == Behavior.IDLE else "normal"
        self.expressions.entryconfigure(0, state=state)
        for index, action in enumerate(self.expression_actions, start=2):
            disabled = action == "fall" and self.config["position_locked"]
            self.expressions.entryconfigure(index, state="disabled" if disabled else "normal")

    def _toggle_lock(self):
        locked = not bool(self.config["position_locked"])
        self.config["position_locked"] = locked
        if locked:
            self._return_to_idle()
        save_config(self.config)

    def _toggle_agent(self):
        self.agent.rules["enabled"] = bool(self.agent_var.get())
        self.agent.save_rules()
        self._return_to_idle()
        message = "智能陪伴已开启" if self.agent.enabled else "智能陪伴已关闭，恢复普通桌宠模式"
        self._show_bubble(message, 2600)

    def _show_agent_status(self):
        messagebox.showinfo("今日状态", self.agent.status_text(), parent=self.root)

    def _set_local_reminder(self, minutes):
        self.agent.set_reminder(minutes)
        self._show_bubble(f"好，{minutes}分钟后提醒你休息", 3000)

    def _cancel_local_reminder(self):
        self.agent.cancel_reminder()
        self._show_bubble("当前休息提醒已取消", 2500)

    def _custom_reminder(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("自定义休息提醒")
        dialog.resizable(False, False)
        dialog.transient(self.root)
        body = tk.Frame(dialog, padx=18, pady=16)
        body.pack()
        tk.Label(body, text="多少分钟后提醒？（1～240）").pack(anchor="w")
        value = tk.StringVar(value="45")
        entry = tk.Entry(body, textvariable=value, width=12)
        entry.pack(anchor="w", pady=10)
        entry.focus_set()

        def confirm():
            try:
                minutes = int(value.get())
            except ValueError:
                minutes = 0
            if not 1 <= minutes <= 240:
                messagebox.showerror("时间有问题", "请输入1～240之间的整数。", parent=dialog)
                return
            dialog.destroy()
            self._set_local_reminder(minutes)

        tk.Button(body, text="确定", command=confirm, width=10).pack(side="left")
        tk.Button(body, text="取消", command=dialog.destroy, width=10).pack(
            side="left",
            padx=8,
        )
        dialog.bind("<Return>", lambda _event: confirm())

    def _visible_pixel_hit(self, root_x, root_y):
        image = self.visible_image
        if image is None:
            return False
        window_x, window_y = self._position()
        local_x = int(root_x - window_x)
        local_y = int(root_y - window_y)
        image_x = local_x - (self.SIZE - image.width) // 2
        image_y = local_y - (self.SIZE - image.height)
        if not (0 <= image_x < image.width and 0 <= image_y < image.height):
            return False
        return image.getpixel((image_x, image_y))[3] >= self.HIT_ALPHA

    def _left_press(self, event):
        if self.drag_offset or not self._visible_pixel_hit(event.x_root, event.y_root):
            return
        self.drag_offset = (event.x, event.y)
        self.drag_previous_x = event.x_root
        self.drag_moved = False

    def _drag_move(self, event):
        if not self.drag_offset or self.config["position_locked"]:
            return
        moved_far_enough = (
            abs(event.x - self.drag_offset[0]) >= 3
            or abs(event.y - self.drag_offset[1]) >= 3
        )
        if not self.drag_moved and moved_far_enough:
            self.drag_moved = True
            self._set_behavior(Behavior.DRAG)
        if not self.drag_moved:
            return

        if self.drag_previous_x is not None and abs(event.x_root - self.drag_previous_x) >= 3:
            self.facing = "right" if event.x_root > self.drag_previous_x else "left"
        self.drag_previous_x = event.x_root
        area = area_at(event.x_root, event.y_root, self.areas)
        if area is None:
            area = nearest_area(event.x_root, event.y_root, self.areas)
        self._move(
            *clamp_to_area(
                event.x_root - self.drag_offset[0],
                event.y_root - self.drag_offset[1],
                self.SIZE,
                self.SIZE,
                area,
            )
        )

    def _drag_end(self, _event):
        if not self.drag_offset:
            return
        was_dragged = self.drag_moved
        self.drag_offset = None
        self.drag_previous_x = None
        x, y = self._position()
        area = nearest_area(x + self.SIZE // 2, y + self.SIZE // 2, self.areas)
        self._move(*clamp_to_area(x, y, self.SIZE, self.SIZE, area))

        if was_dragged:
            self.agent.record_interaction("drag")
        else:
            self.agent.record_interaction("click")
        if self.mode == Mode.DO_NOT_DISTURB:
            self._set_behavior(Behavior.IDLE, animation="loaf", keep=True)
        elif was_dragged:
            self._set_behavior(Behavior.IDLE)
        else:
            self._set_behavior(Behavior.CLICK)
        self.drag_moved = False

    def _show_menu(self, event):
        now = time.monotonic()
        if now - self.last_menu_opened_at < 0.35:
            return
        self.last_menu_opened_at = now
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _right_press(self, event):
        if self._visible_pixel_hit(event.x_root, event.y_root):
            self.pending_menu_position = (int(event.x_root), int(event.y_root))
        else:
            self.pending_menu_position = None

    def _right_release(self, event):
        position = self.pending_menu_position
        self.pending_menu_position = None
        if position:
            event.x_root, event.y_root = position
            self._show_menu(event)

    def _show_bubble(self, message, duration=2200):
        self._hide_bubble()
        self.bubble = tk.Toplevel(self.root)
        self.bubble.overrideredirect(True)
        self.bubble.attributes("-topmost", True)
        tk.Label(
            self.bubble,
            text=message,
            bg="#20242c",
            fg="white",
            padx=12,
            pady=8,
        ).pack()
        self.bubble.update_idletasks()

        x, y = self._position()
        bubble_width = self.bubble.winfo_reqwidth()
        bubble_height = self.bubble.winfo_reqheight()
        area = nearest_area(x + self.SIZE // 2, y + self.SIZE // 2, self.areas)
        bubble_x = min(
            max(x + (self.SIZE - bubble_width) // 2, area.left),
            area.right - bubble_width,
        )
        bubble_y = min(max(y - bubble_height - 8, area.top), area.bottom - bubble_height)
        set_window_position(
            self.bubble.winfo_id(),
            bubble_x,
            bubble_y,
            bubble_width,
            bubble_height,
        )
        self.bubble_timeout_id = self.root.after(duration, self._hide_bubble)

    def _hide_bubble(self):
        if self.bubble_timeout_id is not None:
            try:
                self.root.after_cancel(self.bubble_timeout_id)
            except tk.TclError:
                pass
            self.bubble_timeout_id = None
        if self.bubble:
            self.bubble.destroy()
            self.bubble = None

    def _about_window(self):
        messagebox.showinfo(
            "关于离线行为智能桌宠",
            "PixelPaws 离线行为智能桌宠  v2.1\n\n"
            "• 情境评分、精力、心情和三级陪伴\n"
            "• 工作休息提醒、今日状态和本地气泡\n"
            "• 全屏安静、站岗、免打扰和三种移动方式\n"
            "• 22组动作、双屏移动、跳跃和逐像素透明\n\n"
            "隐私与权限：\n"
            "完全离线，不需要管理员权限；不读取或记录输入文字、"
            "窗口标题、剪贴板、屏幕内容、摄像头或麦克风。\n"
            "行为规则、文案和状态只保存在程序目录。",
            parent=self.root,
        )
