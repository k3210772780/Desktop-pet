from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import dataclass
import time
from PIL import Image, ImageChops


user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
SWP_NOACTIVATE = 0x0010
SWP_NOZORDER = 0x0004
GA_ROOT = 2
MONITOR_DEFAULTTONEAREST = 2
GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
ULW_ALPHA = 0x00000002
AC_SRC_OVER = 0x00
AC_SRC_ALPHA = 0x01
BI_RGB = 0
DIB_RGB_COLORS = 0


class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT),
                ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class SIZE(ctypes.Structure):
    _fields_ = [("cx", wintypes.LONG), ("cy", wintypes.LONG)]


class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
user32.GetAncestor.restype = wintypes.HWND
user32.GetDC.argtypes = [wintypes.HWND]
user32.GetDC.restype = wintypes.HDC
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
user32.GetWindowRect.restype = wintypes.BOOL
user32.GetForegroundWindow.restype = wintypes.HWND
user32.IsIconic.argtypes = [wintypes.HWND]
user32.IsIconic.restype = wintypes.BOOL
user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetClassNameW.restype = ctypes.c_int
user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.MonitorFromWindow.restype = wintypes.HMONITOR
user32.UpdateLayeredWindow.argtypes = [wintypes.HWND,wintypes.HDC,ctypes.POINTER(POINT),
                                       ctypes.POINTER(SIZE),wintypes.HDC,ctypes.POINTER(POINT),
                                       wintypes.COLORREF,ctypes.POINTER(BLENDFUNCTION),wintypes.DWORD]
user32.UpdateLayeredWindow.restype = wintypes.BOOL
gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
gdi32.CreateCompatibleDC.restype = wintypes.HDC
gdi32.CreateDIBSection.argtypes = [wintypes.HDC,ctypes.POINTER(BITMAPINFO),wintypes.UINT,
                                   ctypes.POINTER(ctypes.c_void_p),wintypes.HANDLE,wintypes.DWORD]
gdi32.CreateDIBSection.restype = wintypes.HBITMAP
gdi32.SelectObject.argtypes = [wintypes.HDC,wintypes.HGDIOBJ]
gdi32.SelectObject.restype = wintypes.HGDIOBJ
gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.DeleteDC.argtypes = [wintypes.HDC]
gdi32.CreateRectRgn.argtypes = [ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int]
gdi32.CreateRectRgn.restype = wintypes.HRGN
user32.SetWindowRgn.argtypes = [wintypes.HWND,wintypes.HRGN,wintypes.BOOL]
user32.SetWindowRgn.restype = ctypes.c_int
if ctypes.sizeof(ctypes.c_void_p) == 8:
    user32.GetWindowLongPtrW.argtypes = [wintypes.HWND,ctypes.c_int]
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.SetWindowLongPtrW.argtypes = [wintypes.HWND,ctypes.c_int,ctypes.c_ssize_t]
    user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t


@dataclass(frozen=True)
class WorkArea:
    left: int
    top: int
    right: int
    bottom: int

    @property
    def width(self):
        return self.right - self.left

    @property
    def height(self):
        return self.bottom - self.top

    @property
    def center_x(self):
        return (self.left + self.right) // 2


def monitor_work_areas() -> list[WorkArea]:
    found: list[WorkArea] = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HMONITOR,
                                      wintypes.HDC, ctypes.POINTER(RECT), wintypes.LPARAM)

    def callback(monitor, _dc, _rect, _data):
        info = MONITORINFO(cbSize=ctypes.sizeof(MONITORINFO))
        if user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            r = info.rcWork
            found.append(WorkArea(r.left, r.top, r.right, r.bottom))
        return True

    cb = callback_type(callback)
    user32.EnumDisplayMonitors(None, None, cb, 0)
    return found


def cursor_position() -> tuple[int, int]:
    point = POINT()
    user32.GetCursorPos(ctypes.byref(point))
    return point.x, point.y


def foreground_is_fullscreen() -> bool:
    """Check geometry only; no window title, process name, or screen content is read."""
    hwnd = user32.GetForegroundWindow()
    if not hwnd or user32.IsIconic(hwnd):
        return False

    class_name = ctypes.create_unicode_buffer(64)
    user32.GetClassNameW(hwnd, class_name, len(class_name))
    if class_name.value in {"Progman", "WorkerW", "Shell_TrayWnd"}:
        return False

    monitor = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
    info = MONITORINFO(cbSize=ctypes.sizeof(MONITORINFO))
    rect = RECT()
    if not monitor or not user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
        return False
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return False

    screen = info.rcMonitor
    tolerance = 2
    return (
        rect.left <= screen.left + tolerance
        and rect.top <= screen.top + tolerance
        and rect.right >= screen.right - tolerance
        and rect.bottom >= screen.bottom - tolerance
    )


def set_window_position(hwnd: int, x: int, y: int, width: int, height: int) -> None:
    """Move using absolute virtual-desktop coordinates, including negative values."""
    top_level = user32.GetAncestor(hwnd, GA_ROOT) or hwnd
    user32.SetWindowPos(top_level, None, int(x), int(y), int(width), int(height),
                        SWP_NOACTIVATE | SWP_NOZORDER)


def update_layered_rgba(hwnd: int, image: Image.Image, width: int, height: int,
                        hit_alpha: int = 24) -> None:
    """Render an RGBA frame with native Windows per-pixel alpha transparency."""
    top_level = user32.GetAncestor(hwnd, GA_ROOT) or hwnd
    style = user32.GetWindowLongPtrW(top_level, GWL_EXSTYLE)
    if not style & WS_EX_LAYERED:
        user32.SetWindowLongPtrW(top_level, GWL_EXSTYLE, style | WS_EX_LAYERED)

    cache_key = f"layered_bgra_{width}x{height}"
    region_key = f"layered_region_{width}x{height}_{hit_alpha}"
    pixels = image.info.get(cache_key)
    hit_box = image.info.get(region_key)
    if pixels is None or hit_box is None:
        surface = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        rgba = image.convert("RGBA")
        surface.alpha_composite(rgba, ((width-rgba.width)//2, height-rgba.height))
        hit_mask = surface.getchannel("A").point(
            lambda value: 255 if value >= hit_alpha else 0
        )
        hit_box = hit_mask.getbbox() or (0, 0, 0, 0)
        red, green, blue, alpha = surface.split()
        premultiplied = Image.merge("RGBA", (ImageChops.multiply(red,alpha),
                                              ImageChops.multiply(green,alpha),
                                              ImageChops.multiply(blue,alpha),alpha))
        pixels = premultiplied.tobytes("raw", "BGRA")
        image.info[cache_key] = pixels
        image.info[region_key] = hit_box

    region = gdi32.CreateRectRgn(*hit_box)
    if not region or not user32.SetWindowRgn(top_level, region, False):
        if region:
            gdi32.DeleteObject(region)
        raise ctypes.WinError()

    screen_dc = user32.GetDC(None)
    memory_dc = gdi32.CreateCompatibleDC(screen_dc)
    bits = ctypes.c_void_p()
    info = BITMAPINFO(BITMAPINFOHEADER(ctypes.sizeof(BITMAPINFOHEADER),width,-height,
                                       1,32,BI_RGB,0,0,0,0,0))
    bitmap = gdi32.CreateDIBSection(screen_dc,ctypes.byref(info),DIB_RGB_COLORS,
                                    ctypes.byref(bits),None,0)
    if not memory_dc or not bitmap or not bits.value:
        if bitmap:
            gdi32.DeleteObject(bitmap)
        if memory_dc:
            gdi32.DeleteDC(memory_dc)
        user32.ReleaseDC(None, screen_dc)
        raise OSError("无法创建逐像素透明位图")
    old_bitmap = gdi32.SelectObject(memory_dc,bitmap)
    try:
        ctypes.memmove(bits.value,pixels,len(pixels))
        rect = RECT()
        user32.GetWindowRect(top_level, ctypes.byref(rect))
        destination = POINT(rect.left, rect.top)
        source = POINT(0, 0)
        size = SIZE(width, height)
        blend = BLENDFUNCTION(AC_SRC_OVER, 0, 255, AC_SRC_ALPHA)
        if not user32.UpdateLayeredWindow(top_level,screen_dc,ctypes.byref(destination),
                                          ctypes.byref(size),memory_dc,ctypes.byref(source),
                                          0,ctypes.byref(blend),ULW_ALPHA):
            raise ctypes.WinError()
    finally:
        gdi32.SelectObject(memory_dc, old_bitmap)
        gdi32.DeleteObject(bitmap)
        gdi32.DeleteDC(memory_dc)
        user32.ReleaseDC(None, screen_dc)


def area_at(x: int, y: int, areas: list[WorkArea]) -> WorkArea | None:
    return next((a for a in areas if a.left <= x < a.right and a.top <= y < a.bottom), None)


def clamp_to_area(x: int, y: int, width: int, height: int, area: WorkArea) -> tuple[int, int]:
    return (min(max(int(x), area.left), area.right - width),
            min(max(int(y), area.top), area.bottom - height))


class ActivityPoller:
    """Detects activity type; never translates or stores keys or typed text."""

    MOUSE_BUTTONS = (0x01, 0x02, 0x04)
    VK_LEFT, VK_UP, VK_RIGHT, VK_DOWN = 0x25, 0x26, 0x27, 0x28
    ARROW_KEYS = {VK_LEFT, VK_UP, VK_RIGHT, VK_DOWN}

    def __init__(self):
        self.last_cursor = cursor_position()
        self.last_activity = time.monotonic()
        self._key_down = [False] * 256

    def poll(self) -> set[str]:
        events: set[str] = set()
        current_cursor = cursor_position()
        if current_cursor != self.last_cursor:
            events.add("mouse")
            self.last_cursor = current_cursor

        for vk in range(1, 256):
            down = bool(user32.GetAsyncKeyState(vk) & 0x8000)
            if down and not self._key_down[vk]:
                events.add("click" if vk in self.MOUSE_BUTTONS else "arrow" if vk in self.ARROW_KEYS else "typing")
            self._key_down[vk] = down

        if events:
            self.last_activity = time.monotonic()
        return events

    def arrow_direction(self) -> tuple[int, int]:
        left = bool(user32.GetAsyncKeyState(self.VK_LEFT) & 0x8000)
        right = bool(user32.GetAsyncKeyState(self.VK_RIGHT) & 0x8000)
        up = bool(user32.GetAsyncKeyState(self.VK_UP) & 0x8000)
        down = bool(user32.GetAsyncKeyState(self.VK_DOWN) & 0x8000)
        return int(right) - int(left), int(down) - int(up)

def nearest_area(x: int, y: int, areas: list[WorkArea]) -> WorkArea:
    containing = [a for a in areas if a.left <= x < a.right and a.top <= y < a.bottom]
    if containing:
        return containing[0]
    return min(areas, key=lambda a: abs(a.center_x - x) + abs((a.top + a.bottom) // 2 - y))
