import tkinter as tk
from tkinter import messagebox, ttk

from .config import save_config
from .models import Mode
from .sprites import SpritePlayer


class SettingsMixin:
    """Tabbed settings for movement, the offline agent, and work reminders."""

    def _settings_window(self):
        existing = getattr(self, "settings_window", None)
        if existing and existing.winfo_exists():
            existing.lift()
            return

        window = tk.Toplevel(self.root)
        self.settings_window = window
        window.title("离线智能桌宠设置 v2.1")
        window.geometry("570x570")
        window.resizable(False, False)

        notebook = ttk.Notebook(window)
        notebook.pack(fill="both", expand=True, padx=14, pady=(14, 6))
        movement_tab = ttk.Frame(notebook, padding=16)
        agent_tab = ttk.Frame(notebook, padding=16)
        work_tab = ttk.Frame(notebook, padding=16)
        notebook.add(movement_tab, text="移动与显示")
        notebook.add(agent_tab, text="智能陪伴")
        notebook.add(work_tab, text="工作与休息")

        values = self._settings_variables()
        self._build_movement_tab(movement_tab, values)
        self._build_agent_tab(agent_tab, values)
        self._build_work_tab(work_tab, values)

        buttons = ttk.Frame(window, padding=(14, 6, 14, 14))
        buttons.pack(fill="x")
        ttk.Button(
            buttons,
            text="保存设置",
            command=lambda: self._save_settings(window, values),
        ).pack(side="left")
        ttk.Button(buttons, text="关闭", command=window.destroy).pack(side="right")

    def _settings_variables(self):
        rules = self.agent.rules
        behaviors = rules["behaviors"]
        quiet = rules["quietHours"]
        return {
            "movement_mode": tk.StringVar(value=self.config["movement_mode"]),
            "speed": tk.IntVar(value=self.config["walk_speed"]),
            "interval": tk.IntVar(value=self.config["action_interval"]),
            "scale": tk.IntVar(value=self.config["display_scale"]),
            "dnd": tk.BooleanVar(value=self.mode == Mode.DO_NOT_DISTURB),
            "agent_enabled": tk.BooleanVar(value=rules["enabled"]),
            "personality": tk.StringVar(value=rules["personality"]),
            "bubble_cooldown": tk.IntVar(value=rules["bubbleCooldownMinutes"]),
            "sleep_after": tk.IntVar(value=rules["sleepAfterMinutes"]),
            "fullscreen_quiet": tk.BooleanVar(value=rules["fullScreenQuiet"]),
            "save_state": tk.BooleanVar(value=rules["saveDailyState"]),
            "work_minutes": tk.IntVar(value=rules["workReminderMinutes"]),
            "break_minutes": tk.IntVar(value=rules["breakMinutes"]),
            "quiet_enabled": tk.BooleanVar(value=quiet["enabled"]),
            "quiet_start": tk.StringVar(value=quiet["start"]),
            "quiet_end": tk.StringVar(value=quiet["end"]),
            **{
                key: tk.BooleanVar(value=behaviors[key])
                for key in (
                    "patrol",
                    "cursorPounce",
                    "welcomeBack",
                    "breakReminder",
                    "lateNightReminder",
                    "proactiveBubble",
                )
            },
        }

    def _build_movement_tab(self, tab, values):
        modes = ttk.LabelFrame(tab, text="移动控制方式", padding=10)
        modes.pack(fill="x", pady=(0, 12))
        for text, value in (
            ("自主巡逻", "random"),
            ("跟随鼠标位置", "follow_cursor"),
            ("方向键控制（↑ ↓ ← →）", "arrow_keys"),
        ):
            ttk.Radiobutton(
                modes,
                text=text,
                value=value,
                variable=values["movement_mode"],
            ).pack(anchor="w", pady=2)

        self._scale_row(tab, "移动速度", values["speed"], 2, 10, "")
        self._scale_row(tab, "动作间隔", values["interval"], 5, 30, "秒")

        scale_row = ttk.Frame(tab)
        scale_row.pack(fill="x", pady=10)
        ttk.Label(scale_row, text="桌宠显示缩放", width=16).pack(side="left")
        ttk.Spinbox(
            scale_row,
            from_=20,
            to=150,
            textvariable=values["scale"],
            width=8,
        ).pack(side="left")
        ttk.Label(scale_row, text="%（20～150）", foreground="#555").pack(
            side="left",
            padx=8,
        )

    def _build_agent_tab(self, tab, values):
        ttk.Checkbutton(
            tab,
            text="启用离线行为智能体",
            variable=values["agent_enabled"],
        ).pack(anchor="w", pady=(0, 10))

        personality = ttk.LabelFrame(tab, text="陪伴等级", padding=10)
        personality.pack(fill="x", pady=(0, 10))
        for text, value in (("安静", "quiet"), ("适中", "balanced"), ("活跃", "active")):
            ttk.Radiobutton(
                personality,
                text=text,
                value=value,
                variable=values["personality"],
            ).pack(side="left", padx=(0, 28))

        options = ttk.LabelFrame(tab, text="允许的智能行为", padding=10)
        options.pack(fill="x", pady=(0, 10))
        for text, key in (
            ("自主巡逻", "patrol"),
            ("鼠标扑击", "cursorPounce"),
            ("欢迎回来", "welcomeBack"),
            ("主动陪伴气泡", "proactiveBubble"),
        ):
            ttk.Checkbutton(options, text=text, variable=values[key]).pack(anchor="w", pady=2)

        self._scale_row(
            tab,
            "气泡最短间隔",
            values["bubble_cooldown"],
            1,
            120,
            "分钟",
        )
        self._scale_row(tab, "空闲睡眠", values["sleep_after"], 1, 60, "分钟")
        ttk.Checkbutton(
            tab,
            text="全屏程序运行时保持安静",
            variable=values["fullscreen_quiet"],
        ).pack(anchor="w", pady=8)

    def _build_work_tab(self, tab, values):
        ttk.Checkbutton(
            tab,
            text="启用连续工作休息提醒",
            variable=values["breakReminder"],
        ).pack(anchor="w", pady=(0, 8))
        self._scale_row(tab, "连续工作", values["work_minutes"], 20, 120, "分钟")
        self._scale_row(tab, "建议休息", values["break_minutes"], 1, 30, "分钟")

        ttk.Checkbutton(
            tab,
            text="启用夜间休息提醒",
            variable=values["lateNightReminder"],
        ).pack(anchor="w", pady=(12, 4))
        quiet = ttk.Frame(tab)
        quiet.pack(fill="x", pady=4)
        ttk.Checkbutton(
            quiet,
            text="夜间时段",
            variable=values["quiet_enabled"],
        ).pack(side="left")
        ttk.Entry(quiet, textvariable=values["quiet_start"], width=7).pack(
            side="left",
            padx=(12, 4),
        )
        ttk.Label(quiet, text="至").pack(side="left")
        ttk.Entry(quiet, textvariable=values["quiet_end"], width=7).pack(
            side="left",
            padx=4,
        )

        ttk.Checkbutton(
            tab,
            text="保存今日状态（最多保留最近7天汇总）",
            variable=values["save_state"],
        ).pack(anchor="w", pady=12)
        ttk.Checkbutton(
            tab,
            text="启动后保持工作免打扰",
            variable=values["dnd"],
        ).pack(anchor="w", pady=4)

        actions = ttk.Frame(tab)
        actions.pack(fill="x", pady=18)
        ttk.Button(actions, text="查看今日状态", command=self._show_agent_status).pack(
            side="left"
        )
        ttk.Button(actions, text="清除今日状态", command=self._confirm_clear_today).pack(
            side="left",
            padx=10,
        )

    def _scale_row(self, parent, label, variable, minimum, maximum, suffix):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=8)
        ttk.Label(row, text=label, width=16).pack(side="left")
        ttk.Scale(row, from_=minimum, to=maximum, variable=variable).pack(
            side="left",
            fill="x",
            expand=True,
        )
        value_label = ttk.Label(row, width=8, anchor="e")
        value_label.pack(side="right", padx=(8, 0))

        def update_label(*_):
            try:
                value_label.configure(text=f"{int(float(variable.get()))}{suffix}")
            except (ValueError, tk.TclError):
                value_label.configure(text="—")

        variable.trace_add("write", update_label)
        update_label()

    def _save_settings(self, window, values):
        try:
            speed = int(values["speed"].get())
            interval = int(values["interval"].get())
            scale = int(values["scale"].get())
            bubble_cooldown = int(values["bubble_cooldown"].get())
            sleep_after = int(values["sleep_after"].get())
            work_minutes = int(values["work_minutes"].get())
            break_minutes = int(values["break_minutes"].get())
        except (ValueError, tk.TclError):
            messagebox.showerror("设置有问题", "所有时间、速度和缩放必须是数字。", parent=window)
            return

        if not 2 <= speed <= 10 or not 5 <= interval <= 30:
            messagebox.showerror("设置有问题", "移动速度或动作间隔超出范围。", parent=window)
            return
        if not 20 <= scale <= 150:
            messagebox.showerror("设置有问题", "显示缩放必须在20%～150%之间。", parent=window)
            return
        if not 1 <= bubble_cooldown <= 120 or not 1 <= sleep_after <= 60:
            messagebox.showerror("设置有问题", "气泡间隔或睡眠时间超出范围。", parent=window)
            return
        if not 20 <= work_minutes <= 120 or not 1 <= break_minutes <= 30:
            messagebox.showerror("设置有问题", "工作或休息时长超出范围。", parent=window)
            return
        if not self._valid_clock(values["quiet_start"].get()) or not self._valid_clock(
            values["quiet_end"].get()
        ):
            messagebox.showerror("设置有问题", "夜间时间必须使用 HH:MM 格式。", parent=window)
            return
        if scale > 60 and not messagebox.askyesno(
            "显示尺寸较大",
            "超过60%时，部分精灵图可能超出180×180桌宠窗口。仍然保存吗？",
            parent=window,
        ):
            return

        replacement = SpritePlayer(self.root, scale)
        if replacement.error:
            messagebox.showerror("缩放应用失败", replacement.error, parent=window)
            return

        self.config.update(
            movement_mode=values["movement_mode"].get(),
            walk_speed=speed,
            action_interval=interval,
            display_scale=scale,
        )
        rules = self.agent.rules
        rules.update(
            enabled=bool(values["agent_enabled"].get()),
            personality=values["personality"].get(),
            bubbleCooldownMinutes=bubble_cooldown,
            sleepAfterMinutes=sleep_after,
            fullScreenQuiet=bool(values["fullscreen_quiet"].get()),
            saveDailyState=bool(values["save_state"].get()),
            workReminderMinutes=work_minutes,
            breakMinutes=break_minutes,
        )
        rules["quietHours"].update(
            enabled=bool(values["quiet_enabled"].get()),
            start=values["quiet_start"].get(),
            end=values["quiet_end"].get(),
        )
        for key in (
            "patrol",
            "cursorPounce",
            "welcomeBack",
            "breakReminder",
            "lateNightReminder",
            "proactiveBubble",
        ):
            rules["behaviors"][key] = bool(values[key].get())

        self.sprites = replacement
        self.last_drawn = object()
        self._return_to_idle()
        save_config(self.config)
        self.agent.save_rules()
        self.agent.save_state(force=True)
        self.agent_var.set(self.agent.enabled)
        window.destroy()

        requested_dnd = bool(values["dnd"].get())
        if requested_dnd != (self.mode == Mode.DO_NOT_DISTURB):
            self.dnd_var.set(requested_dnd)
            self._toggle_dnd()

    def _valid_clock(self, value):
        try:
            hour, minute = (int(part) for part in str(value).split(":"))
        except (ValueError, TypeError):
            return False
        return 0 <= hour <= 23 and 0 <= minute <= 59

    def _confirm_clear_today(self):
        if messagebox.askyesno(
            "清除今日状态",
            "确定清除今天的活跃时长、互动、提醒、精力和心情记录吗？",
            parent=self.settings_window,
        ):
            self.agent.clear_today()
            messagebox.showinfo("已清除", "今日状态已恢复默认值。", parent=self.settings_window)
