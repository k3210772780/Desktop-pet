from collections import deque
import random
import time
import tkinter as tk
from tkinter import messagebox

from PIL import Image, ImageDraw

from .config import load_config, save_config
from .interface import UserInterfaceMixin
from .models import Behavior, Mode
from .movement import MovementMixin
from .offline_agent import OfflineBehaviorAgent
from .settings_ui import SettingsMixin
from .sprites import SpritePlayer
from .windows import (
    ActivityPoller,
    foreground_is_fullscreen,
    monitor_work_areas,
    set_window_position,
    update_layered_rgba,
)


class DesktopPetApp(MovementMixin, SettingsMixin, UserInterfaceMixin):
    SIZE = 180
    TICK_MS = 33
    LEGACY_SLEEP_AFTER = 90
    HIT_ALPHA = 24
    RANDOM_ACTIONS = (("stretch", 3.2), ("groom", 4.0), ("loaf", 5.0))

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("离线智能桌宠 v2.1")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.geometry(f"{self.SIZE}x{self.SIZE}+0+0")

        self.config = load_config()
        self.sprites = SpritePlayer(self.root, self.config["display_scale"])
        self.activity = ActivityPoller()
        self.agent = OfflineBehaviorAgent()
        self.areas = monitor_work_areas()
        self.mode = Mode.DO_NOT_DISTURB if self.config["do_not_disturb"] else Mode.NORMAL

        self.behavior = Behavior.IDLE
        self.behavior_since = time.monotonic()
        self.facing = "right"
        self.last_key = 0.0
        self.key_times = deque(maxlen=30)
        self.target = None
        self.arrival_action = None

        self.drag_offset = None
        self.drag_previous_x = None
        self.drag_moved = False
        self.animation_override = "loaf" if self.mode == Mode.DO_NOT_DISTURB else None
        self.expression_until = 0.0
        self.pending_expression = None
        self.pre_sleep_yawned = False

        self.physics_vx = 0.0
        self.physics_vy = 0.0
        self.physics_floor = 0
        self.physics_area = None
        self.physics_anim = "pounce"

        self.last_drawn = object()
        self.visible_image = None
        self.pending_menu_position = None
        self.last_menu_opened_at = 0.0
        self.bubble = None
        self.bubble_timeout_id = None
        self.fullscreen_active = False

        self.fallback_image = Image.new("RGBA", (76, 70), (0, 0, 0, 0))
        fallback_draw = ImageDraw.Draw(self.fallback_image)
        fallback_draw.ellipse(
            (0, 0, 75, 69),
            fill="#8bd3dd",
            outline="#29303b",
            width=3,
        )

        self.next_auto_action_at = 0.0
        self.last_random_action = None
        self.active_auto_kind = None
        self._schedule_auto(8, 15)

        self.root.bind("<ButtonPress-1>", self._left_press)
        self.root.bind("<B1-Motion>", self._drag_move)
        self.root.bind("<ButtonRelease-1>", self._drag_end)
        self.root.bind("<ButtonPress-3>", self._right_press)
        self.root.bind("<ButtonRelease-3>", self._right_release)
        self.root.protocol("WM_DELETE_WINDOW", self._exit_app)

        self._build_menu()
        self.root.after(120, self._initial_position)
        self.root.after(self.TICK_MS, self._tick)
        self.root.after(2500, self._decide)

    def run(self):
        self.root.mainloop()

    def _exit_app(self):
        self.agent.save_state(force=True)
        self.root.destroy()

    def _initial_position(self):
        if not self.areas:
            return

        primary = self.areas[0]
        self._move(primary.center_x - self.SIZE // 2, primary.bottom - self.SIZE)
        if not self.config.get("screen_intro_shown", False):
            self.config["screen_intro_shown"] = True
            save_config(self.config)
            self.root.after(
                350,
                lambda: self._show_bubble(f"已识别 {len(self.areas)} 块屏幕", 3000),
            )
        if self.sprites.error:
            self.root.after(
                500,
                lambda: self._show_bubble(f"皮肤加载失败：{self.sprites.error}", 6000),
            )

    def _position(self):
        return self.root.winfo_x(), self.root.winfo_y()

    def _move(self, x, y):
        set_window_position(self.root.winfo_id(), int(x), int(y), self.SIZE, self.SIZE)

    def _set_behavior(self, behavior, animation=None, keep=False):
        if behavior != self.behavior or animation != self.animation_override:
            self.behavior = behavior
            self.behavior_since = time.monotonic()
        if behavior != Behavior.WALK:
            self.target = None
            self.arrival_action = None
        if animation is not None:
            self.animation_override = animation
        elif not keep and behavior != Behavior.EXPRESSION:
            self.animation_override = None

    def _return_to_idle(self):
        self.pending_expression = None
        self.physics_area = None
        self.active_auto_kind = None
        self._set_behavior(Behavior.IDLE)
        self._schedule_auto(8, 15)

    def _request_expression(self, animation, duration):
        if animation == "fall" and self.config["position_locked"]:
            messagebox.showinfo(
                "正在站岗",
                "请先选择“巡逻”，再使用跳跃 / 下落。",
                parent=self.root,
            )
            return
        self.agent.record_interaction("expression")
        if self.behavior == Behavior.SLEEP:
            self.pending_expression = (animation, duration)
            self._set_behavior(Behavior.WAKE)
            return
        if animation == "fall":
            self._start_jump()
            return
        self._play_expression(animation, duration, auto_kind="manual")

    def _play_expression(self, animation, duration, auto_kind=None):
        self.active_auto_kind = auto_kind
        self.expression_until = time.monotonic() + duration
        self._set_behavior(Behavior.EXPRESSION, animation=animation, keep=True)

    def _schedule_auto(self, minimum, maximum):
        # 12秒为原始节奏；设置项按比例调节普通及特殊动作的冷却时间。
        factor = float(self.config["action_interval"]) / 12.0
        delay = random.uniform(minimum * factor, maximum * factor)
        self.next_auto_action_at = time.monotonic() + delay

    def _choose_life_action(self):
        choices = [item for item in self.RANDOM_ACTIONS if item[0] != self.last_random_action]
        action, duration = random.choice(choices or list(self.RANDOM_ACTIONS))
        self.last_random_action = action
        self._play_expression(action, duration, auto_kind="life")

    def _toggle_dnd(self):
        enabled = bool(self.dnd_var.get())
        self.pending_expression = None
        self.physics_area = None
        self.active_auto_kind = None
        if enabled:
            self.mode = Mode.DO_NOT_DISTURB
            self._set_behavior(Behavior.IDLE, animation="loaf", keep=True)
        else:
            self.mode = Mode.NORMAL
            self.agent.discard_overdue_reminders()
            self._set_behavior(Behavior.WAKE)
            self._schedule_auto(8, 15)
        self.config["do_not_disturb"] = enabled
        save_config(self.config)

    def _decide(self):
        now = time.monotonic()
        inactive = now - self.activity.last_activity
        busy = self.behavior != Behavior.IDLE
        self.fullscreen_active = foreground_is_fullscreen()

        if self.agent.enabled:
            sleep_after = self.agent.sleep_after_seconds
            if self.mode == Mode.NORMAL and not busy and not self.drag_offset:
                if inactive >= sleep_after:
                    self._set_behavior(Behavior.SLEEP)
                elif inactive >= sleep_after - 12 and not self.pre_sleep_yawned:
                    self.pre_sleep_yawned = True
                    self._play_expression("yawn", 3.0, auto_kind="sleep")
                elif now >= self.next_auto_action_at:
                    self._run_agent_decision(inactive)
        else:
            self._legacy_decision(now, inactive, busy)

        self.root.after(2500, self._decide)

    def _run_agent_decision(self, inactive):
        can_move = (
            not self.config["position_locked"]
            and self.config["movement_mode"] == "random"
        )
        can_pounce = can_move and self._can_pounce()
        decision = self.agent.decide(
            inactive_seconds=inactive,
            fullscreen=self.fullscreen_active,
            mode=self.mode,
            behavior=self.behavior,
            can_move=can_move,
            can_pounce=can_pounce,
        )
        if decision is None or decision.kind == "stay":
            self._schedule_auto(8, 15)
            return

        if decision.message:
            self._show_bubble(decision.message, 4500)
            self.agent.mark_message_shown()
        if decision.movement == "walk":
            self._choose_walk()
        elif decision.movement == "edge":
            self._choose_walk(True)
        elif decision.movement == "pounce":
            self._start_crouch()
        elif decision.animation:
            self._play_expression(
                decision.animation,
                decision.duration,
                auto_kind="agent",
            )
        else:
            self._schedule_auto(8, 15)

    def _legacy_decision(self, now, inactive, busy):
        if self.mode != Mode.NORMAL or busy or self.drag_offset:
            return
        if inactive >= self.LEGACY_SLEEP_AFTER:
            self._set_behavior(Behavior.SLEEP)
            return
        if inactive >= self.LEGACY_SLEEP_AFTER - 12 and not self.pre_sleep_yawned:
            self.pre_sleep_yawned = True
            self._play_expression("yawn", 3.0, auto_kind="sleep")
            return
        if now < self.next_auto_action_at:
            return

        roll = random.random()
        can_patrol = (
            not self.config["position_locked"]
            and self.config["movement_mode"] == "random"
        )
        if roll < 0.20 and can_patrol:
            self._choose_walk()
        elif roll < 0.27 and can_patrol:
            self._choose_walk(True)
        elif roll < 0.30 and can_patrol and self._can_pounce():
            self._start_crouch()
        elif 0.30 <= roll < 0.50:
            self._choose_life_action()
        else:
            self._set_behavior(Behavior.IDLE)
            self._schedule_auto(8, 15)

    def _tick(self):
        now = time.monotonic()
        events = self.activity.poll()
        if self.agent.enabled:
            self.agent.observe(events, now - self.activity.last_activity)
        blocked_behaviors = (Behavior.EXPRESSION, Behavior.DRAG, Behavior.PHYSICS)
        if self.mode != Mode.NORMAL or self.behavior in blocked_behaviors:
            events = set()
        if events:
            self.pre_sleep_yawned = False

        if "typing" in events:
            self.last_key = now
            self.key_times.append(now)
            next_behavior = Behavior.WAKE if self.behavior == Behavior.SLEEP else Behavior.TYPING
            self._set_behavior(next_behavior)
        elif "click" in events and self.behavior == Behavior.SLEEP:
            self._set_behavior(Behavior.WAKE)
        elif "mouse" in events:
            if self.behavior == Behavior.SLEEP:
                self._set_behavior(Behavior.WAKE)
            elif (
                not self.config["position_locked"]
                and self.config["movement_mode"] == "follow_cursor"
                and self.behavior != Behavior.TYPING
                and not (
                    self.agent.enabled
                    and self.agent.rules["fullScreenQuiet"]
                    and self.fullscreen_active
                )
            ):
                self._follow_cursor()

        control_blocked = (
            Behavior.EXPRESSION,
            Behavior.PHYSICS,
            Behavior.CROUCH,
            Behavior.SLEEP,
            Behavior.WAKE,
        )
        can_control = (
            self.mode == Mode.NORMAL
            and not self.config["position_locked"]
            and not self.drag_offset
            and self.behavior not in control_blocked
        )
        if can_control and self.config["movement_mode"] == "arrow_keys":
            delta_x, delta_y = self.activity.arrow_direction()
            if delta_x or delta_y:
                self._move_by_arrow(delta_x, delta_y)
            elif self.behavior == Behavior.WALK:
                self._set_behavior(Behavior.IDLE)
                self._schedule_auto(8, 15)

        self._update_timed_behavior(now)
        if self.behavior == Behavior.WALK and self.target and not self.drag_offset:
            self._advance_walk()
        elif self.behavior == Behavior.PHYSICS:
            self._advance_physics()

        self._draw()
        self.root.after(self.TICK_MS, self._tick)

    def _update_timed_behavior(self, now):
        elapsed = now - self.behavior_since
        if self.behavior == Behavior.WAKE and elapsed > 0.9:
            if self.pending_expression:
                action, duration = self.pending_expression
                self.pending_expression = None
                if action == "fall":
                    self._start_jump()
                else:
                    self._play_expression(action, duration, auto_kind="manual")
            else:
                self._set_behavior(Behavior.IDLE)
        elif self.behavior == Behavior.EXPRESSION and now >= self.expression_until:
            self._finish_expression()
        elif self.behavior == Behavior.CLICK and elapsed > 1.0:
            self._set_behavior(Behavior.IDLE)
        elif self.behavior == Behavior.TYPING and now - self.last_key > 1.8:
            self._set_behavior(Behavior.IDLE)
        elif self.behavior == Behavior.CROUCH and elapsed > 0.65:
            self._launch_pounce()
        elif self.behavior == Behavior.SIDEREST and elapsed > 6.0:
            self._set_behavior(Behavior.IDLE)
            self._schedule_auto(15, 25)

    def _finish_expression(self):
        kind = self.active_auto_kind
        self.active_auto_kind = None
        if self.mode == Mode.DO_NOT_DISTURB:
            self._set_behavior(Behavior.IDLE, animation="loaf", keep=True)
        else:
            self._set_behavior(Behavior.IDLE)

        if kind == "life":
            self._schedule_auto(12, 20)
        elif kind == "pounce":
            self._schedule_auto(20, 30)
        elif kind == "manual":
            self._schedule_auto(8, 15)
        elif kind == "agent":
            self._schedule_auto(12, 20)

    def _animation(self):
        if self.animation_override:
            return self.animation_override
        if self.behavior == Behavior.WALK:
            return "walk"
        if self.behavior == Behavior.TYPING:
            recent_keys = sum(
                pressed_at >= time.monotonic() - 1 for pressed_at in self.key_times
            )
            return "typingfast" if recent_keys >= 7 else "typing"

        behavior_animations = {
            Behavior.SLEEP: "sleep",
            Behavior.WAKE: "wakeup",
            Behavior.CLICK: "pet",
            Behavior.DRAG: "drag",
        }
        default = "loaf" if self.mode == Mode.DO_NOT_DISTURB else "idle"
        return behavior_animations.get(self.behavior, default)

    def _draw(self):
        image = self.sprites.frame(
            self._animation(),
            time.monotonic() - self.behavior_since,
            self.facing,
        )
        if image is self.last_drawn:
            return
        self.last_drawn = image
        self.visible_image = image or self.fallback_image
        update_layered_rgba(
            self.root.winfo_id(),
            self.visible_image,
            self.SIZE,
            self.SIZE,
        )
