from __future__ import annotations

import json
from pathlib import Path
import sys


DEFAULTS = {
    "movement_mode": "random",
    "walk_speed": 5,
    "action_interval": 12,
    "display_scale": 50,
    "position_locked": False,
    "do_not_disturb": False,
    "screen_intro_shown": False,
}
APP_DIR = (Path(sys.executable).resolve().parent if getattr(sys, "frozen", False)
           else Path(__file__).resolve().parent.parent)
CONFIG_PATH = APP_DIR / "settings.json"


def load_config() -> dict:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    clean = {**DEFAULTS, **{k: data[k] for k in DEFAULTS if k in data}}
    if clean["movement_mode"] not in ("random", "follow_cursor", "arrow_keys"):
        clean["movement_mode"] = "random"
    clean["walk_speed"] = min(10, max(2, int(clean["walk_speed"])))
    clean["action_interval"] = min(30, max(5, int(clean["action_interval"])))
    clean["display_scale"] = min(150, max(20, int(clean["display_scale"])))
    return clean


def save_config(config: dict) -> None:
    clean = {k: config.get(k, value) for k, value in DEFAULTS.items()}
    CONFIG_PATH.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
