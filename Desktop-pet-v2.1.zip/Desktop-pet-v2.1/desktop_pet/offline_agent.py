from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
import json
from pathlib import Path
import random
import time

from .config import APP_DIR
from .models import Behavior, Mode


DEFAULT_RULES = {
    "enabled": True,
    "personality": "balanced",
    "workReminderMinutes": 45,
    "breakMinutes": 5,
    "bubbleCooldownMinutes": 15,
    "sleepAfterMinutes": 10,
    "fullScreenQuiet": True,
    "saveDailyState": True,
    "historyDays": 7,
    "quietHours": {"enabled": True, "start": "23:00", "end": "08:00"},
    "behaviors": {
        "patrol": True,
        "cursorPounce": True,
        "welcomeBack": True,
        "breakReminder": True,
        "lateNightReminder": True,
        "proactiveBubble": True,
    },
    "moodAnimations": {
        "sleepy": {"action": "yawn", "duration": 3.0},
        "focused": {"action": "loaf", "duration": 5.0},
        "happy": {"action": "proud", "duration": 2.5},
        "active": {"action": "play", "duration": 4.0},
        "calm": {"action": "groom", "duration": 4.0},
    },
}

DEFAULT_MESSAGES = {
    "focus": ["你正在认真工作呢。", "我先安静陪着你。"],
    "break": ["工作一会儿了，休息一下眼睛吧。"],
    "welcome": ["你回来啦。"],
    "lateNight": ["已经很晚了，注意休息。"],
    "happy": ["我会在这里陪你。"],
}

PERSONALITY = {
    "quiet": {"movement": 0.35, "life": 0.55, "bubble": 0.0},
    "balanced": {"movement": 1.0, "life": 1.0, "bubble": 1.0},
    "active": {"movement": 1.5, "life": 1.25, "bubble": 1.35},
}


@dataclass(frozen=True)
class AgentDecision:
    kind: str
    animation: str | None = None
    duration: float = 0.0
    message: str | None = None
    movement: str | None = None


def _merge_dict(defaults, supplied):
    result = dict(defaults)
    if not isinstance(supplied, dict):
        return result
    for key, value in supplied.items():
        if key in result:
            if isinstance(result[key], dict):
                result[key] = _merge_dict(result[key], value)
            else:
                result[key] = value
    return result


class OfflineBehaviorAgent:
    """Local, deterministic behavior agent. It never reads typed text or uses a network."""

    def __init__(self):
        self.rules_path = APP_DIR / "behavior_rules.json"
        self.messages_path = APP_DIR / "messages.json"
        self.state_path = APP_DIR / "agent_state.json"
        self.rules = self._load_rules()
        self.messages = self._load_messages()
        self.state = self._load_state()

        self.last_observed_at = time.monotonic()
        self.last_saved_at = self.last_observed_at
        self.last_active_at = self.last_observed_at
        self.was_away = False
        self.welcome_pending = False
        self.reminder_due_at = None
        self.last_message_category = None

    @property
    def enabled(self):
        return bool(self.rules["enabled"])

    @property
    def sleep_after_seconds(self):
        return int(self.rules["sleepAfterMinutes"]) * 60

    @property
    def daily(self):
        return self.state["today"]

    def _load_json(self, path: Path, fallback):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return fallback

    def _load_rules(self):
        rules = _merge_dict(DEFAULT_RULES, self._load_json(self.rules_path, {}))
        if rules["personality"] not in PERSONALITY:
            rules["personality"] = "balanced"
        for key, minimum, maximum in (
            ("workReminderMinutes", 20, 120),
            ("breakMinutes", 1, 30),
            ("bubbleCooldownMinutes", 1, 120),
            ("sleepAfterMinutes", 1, 60),
            ("historyDays", 1, 30),
        ):
            try:
                value = int(rules[key])
            except (TypeError, ValueError):
                value = int(DEFAULT_RULES[key])
            rules[key] = min(maximum, max(minimum, value))
        for mood, fallback in DEFAULT_RULES["moodAnimations"].items():
            spec = rules["moodAnimations"].get(mood, fallback)
            action = str(spec.get("action", fallback["action"])).strip()
            try:
                duration = float(spec.get("duration", fallback["duration"]))
            except (TypeError, ValueError):
                duration = float(fallback["duration"])
            rules["moodAnimations"][mood] = {
                "action": action or fallback["action"],
                "duration": max(0.5, duration),
            }
        return rules

    def _load_messages(self):
        supplied = self._load_json(self.messages_path, {})
        result = {}
        for category, fallback in DEFAULT_MESSAGES.items():
            values = supplied.get(category, fallback)
            if not isinstance(values, list):
                values = fallback
            result[category] = [str(item)[:40] for item in values if str(item).strip()] or fallback
        return result

    def _new_daily(self):
        return {
            "date": date.today().isoformat(),
            "activeSeconds": 0,
            "awaySeconds": 0,
            "continuousWorkSeconds": 0,
            "breakCount": 0,
            "interactionCount": 0,
            "reminderCount": 0,
            "energy": 80.0,
            "mood": "calm",
            "lastReminderAt": None,
            "lastMessageAt": None,
        }

    def _load_state(self):
        fallback = {"today": self._new_daily(), "history": []}
        supplied = self._load_json(self.state_path, fallback)
        if not isinstance(supplied, dict):
            supplied = fallback
        today = supplied.get("today")
        history = supplied.get("history", [])
        if not isinstance(today, dict):
            today = self._new_daily()
        if today.get("date") != date.today().isoformat():
            if today.get("date"):
                history.append(today)
            today = self._new_daily()
        today = {**self._new_daily(), **today}
        for key in (
            "activeSeconds",
            "awaySeconds",
            "continuousWorkSeconds",
            "energy",
        ):
            try:
                today[key] = float(today[key])
            except (TypeError, ValueError):
                today[key] = float(self._new_daily()[key])
        for key in ("breakCount", "interactionCount", "reminderCount"):
            try:
                today[key] = int(today[key])
            except (TypeError, ValueError):
                today[key] = int(self._new_daily()[key])
        if not isinstance(history, list):
            history = []
        return {"today": today, "history": history}

    def save_rules(self):
        self.rules_path.write_text(
            json.dumps(self.rules, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def save_state(self, force=False):
        if not self.rules["saveDailyState"]:
            if force:
                try:
                    self.state_path.unlink()
                except FileNotFoundError:
                    pass
            return
        now = time.monotonic()
        if not force and now - self.last_saved_at < 60:
            return
        self._trim_history()
        self.state_path.write_text(
            json.dumps(self.state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        self.last_saved_at = now

    def _trim_history(self):
        earliest = date.today() - timedelta(days=int(self.rules["historyDays"]))
        kept = []
        for entry in self.state.get("history", []):
            try:
                entry_date = date.fromisoformat(str(entry.get("date")))
            except ValueError:
                continue
            if entry_date >= earliest:
                kept.append(entry)
        self.state["history"] = kept

    def observe(self, events, inactive_seconds):
        self._rollover_day()
        now = time.monotonic()
        elapsed = min(5.0, max(0.0, now - self.last_observed_at))
        self.last_observed_at = now
        active = inactive_seconds < 15

        if active:
            self.daily["activeSeconds"] += elapsed
            self.daily["continuousWorkSeconds"] += elapsed
            self.daily["energy"] = max(0.0, self.daily["energy"] - elapsed / 450)
            self.last_active_at = now
            if self.was_away:
                self.welcome_pending = True
                self.was_away = False
        else:
            self.daily["awaySeconds"] += elapsed
            if inactive_seconds >= int(self.rules["breakMinutes"]) * 60:
                if not self.was_away:
                    self.daily["breakCount"] += 1
                self.was_away = True
                self.daily["continuousWorkSeconds"] = 0
                self.daily["energy"] = min(100.0, self.daily["energy"] + elapsed / 180)

        self._update_mood(active)
        self.save_state()

    def _rollover_day(self):
        today = date.today().isoformat()
        if self.daily["date"] == today:
            return
        self.state["history"].append(self.daily)
        self.state["today"] = self._new_daily()
        self._trim_history()

    def _update_mood(self, active):
        now = datetime.now()
        energy = float(self.daily["energy"])
        recent_interaction = self.daily.get("lastInteractionAt")
        if recent_interaction and time.time() - float(recent_interaction) < 120:
            mood = "happy"
        elif energy < 30 or now.hour >= 23:
            mood = "sleepy"
        elif active and self.daily["continuousWorkSeconds"] >= 600:
            mood = "focused"
        elif energy >= 75:
            mood = "active"
        else:
            mood = "calm"
        self.daily["mood"] = mood

    def record_interaction(self, kind):
        self.daily["interactionCount"] += 1
        self.daily["lastInteraction"] = kind
        self.daily["lastInteractionAt"] = time.time()
        self.daily["energy"] = min(100.0, float(self.daily["energy"]) + 1.5)

    def _quiet_hours(self):
        quiet = self.rules["quietHours"]
        if not quiet["enabled"]:
            return False
        now = datetime.now().strftime("%H:%M")
        start, end = str(quiet["start"]), str(quiet["end"])
        return start <= now < end if start < end else now >= start or now < end

    def _bubble_ready(self):
        value = self.daily.get("lastMessageAt")
        if not value:
            return True
        cooldown = int(self.rules["bubbleCooldownMinutes"]) * 60
        return time.time() - float(value) >= cooldown

    def _reminder_ready(self):
        value = self.daily.get("lastReminderAt")
        if not value:
            return True
        return time.time() - float(value) >= 30 * 60

    def _message(self, category):
        choices = self.messages.get(category, DEFAULT_MESSAGES[category])
        if len(choices) > 1 and category == self.last_message_category:
            choices = choices[1:] + choices[:1]
        self.last_message_category = category
        return random.choice(choices)

    def mark_message_shown(self):
        self.daily["lastMessageAt"] = time.time()

    def set_reminder(self, minutes):
        self.reminder_due_at = time.monotonic() + int(minutes) * 60

    def cancel_reminder(self):
        self.reminder_due_at = None

    def discard_overdue_reminders(self):
        if self.reminder_due_at is not None and self.reminder_due_at <= time.monotonic():
            self.reminder_due_at = None
        threshold = int(self.rules["workReminderMinutes"]) * 60
        if self.daily["continuousWorkSeconds"] >= threshold:
            self.daily["lastReminderAt"] = time.time()

    def _manual_reminder_due(self):
        return self.reminder_due_at is not None and time.monotonic() >= self.reminder_due_at

    def decide(self, inactive_seconds, fullscreen, mode, behavior, can_move, can_pounce):
        if not self.enabled or mode == Mode.DO_NOT_DISTURB:
            return None
        if behavior != Behavior.IDLE:
            return None

        quiet_screen = fullscreen and self.rules["fullScreenQuiet"]
        slowed_down = 3 <= inactive_seconds < int(self.rules["breakMinutes"]) * 60
        behaviors = self.rules["behaviors"]

        if self._manual_reminder_due() and not quiet_screen:
            self.reminder_due_at = None
            self.daily["reminderCount"] += 1
            self.daily["lastReminderAt"] = time.time()
            return AgentDecision("reminder", "stretch", 3.2, self._message("break"))

        work_due = (
            behaviors["breakReminder"]
            and self.daily["continuousWorkSeconds"] >= int(self.rules["workReminderMinutes"]) * 60
            and self._reminder_ready()
        )
        if work_due and slowed_down and not quiet_screen:
            self.daily["reminderCount"] += 1
            self.daily["lastReminderAt"] = time.time()
            return AgentDecision("reminder", "stretch", 3.2, self._message("break"))

        if self.welcome_pending:
            self.welcome_pending = False
            if behaviors["welcomeBack"] and not quiet_screen and self._bubble_ready():
                return AgentDecision("welcome", "proud", 2.5, self._message("welcome"))

        if quiet_screen:
            return None

        if (
            behaviors["lateNightReminder"]
            and self._quiet_hours()
            and self._bubble_ready()
            and slowed_down
        ):
            return AgentDecision("late_night", "yawn", 3.0, self._message("lateNight"))

        profile = PERSONALITY[self.rules["personality"]]
        candidates = [(50.0, AgentDecision("stay"))]
        energy = float(self.daily["energy"])
        mood = self.daily["mood"]

        if can_move and behaviors["patrol"]:
            candidates.append((32 * profile["movement"] + energy / 5, AgentDecision("patrol", movement="walk")))
            candidates.append((14 * profile["movement"] + energy / 8, AgentDecision("edge", movement="edge")))
        if can_move and can_pounce and behaviors["cursorPounce"] and energy >= 45:
            candidates.append((18 * profile["movement"] + energy / 6, AgentDecision("pounce", movement="pounce")))

        mood_animation = self.rules["moodAnimations"][mood]
        action = str(mood_animation["action"])
        duration = max(0.5, float(mood_animation["duration"]))
        candidates.append((30 * profile["life"] + random.uniform(0, 18), AgentDecision("life", action, duration)))

        if behaviors["proactiveBubble"] and profile["bubble"] and self._bubble_ready() and slowed_down:
            category = "focus" if mood == "focused" else "happy"
            candidates.append((46 * profile["bubble"], AgentDecision("bubble", "talk", 4.0, self._message(category))))

        score, decision = max(candidates, key=lambda item: item[0] + random.uniform(0, 12))
        return decision if score >= 45 else AgentDecision("stay")

    def status_text(self):
        active_minutes = int(self.daily["activeSeconds"] // 60)
        continuous_minutes = int(self.daily["continuousWorkSeconds"] // 60)
        recent = self.state.get("history", []) + [self.daily]
        recent_active_minutes = int(sum(float(item.get("activeSeconds", 0)) for item in recent) // 60)
        recent_breaks = sum(int(item.get("breakCount", 0)) for item in recent)
        mood_names = {
            "calm": "平静",
            "happy": "开心",
            "sleepy": "困倦",
            "focused": "专注陪伴",
            "active": "活跃",
        }
        personality_names = {"quiet": "安静", "balanced": "适中", "active": "活跃"}
        return (
            "今日陪伴\n\n"
            f"连续工作：{continuous_minutes} 分钟\n"
            f"今日活跃：{active_minutes // 60} 小时 {active_minutes % 60} 分钟\n"
            f"近7天活跃：{recent_active_minutes // 60} 小时 {recent_active_minutes % 60} 分钟\n"
            f"已休息：{int(self.daily['breakCount'])} 次\n"
            f"近7天休息：{recent_breaks} 次\n"
            f"桌宠互动：{int(self.daily['interactionCount'])} 次\n"
            f"提醒次数：{int(self.daily['reminderCount'])} 次\n"
            f"当前精力：{int(self.daily['energy'])}\n"
            f"当前心情：{mood_names.get(self.daily['mood'], '平静')}\n"
            f"智能陪伴：{personality_names[self.rules['personality']]}"
        )

    def clear_today(self):
        self.state["today"] = self._new_daily()
        self.save_state(force=True)
