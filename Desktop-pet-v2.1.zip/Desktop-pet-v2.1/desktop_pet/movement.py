import math
import random
import time

from .models import Behavior, Mode
from .windows import area_at, clamp_to_area, cursor_position, monitor_work_areas, nearest_area


class MovementMixin:
    """Walking, cross-screen movement, cursor following, and simple physics."""

    def _choose_walk(self, to_edge=False):
        if self.mode != Mode.NORMAL or self.config["position_locked"]:
            return

        self.areas = monitor_work_areas() or self.areas
        area = random.choice(self.areas)
        current_x, current_y = self._position()
        if to_edge:
            target_x = random.choice((area.left, area.right - self.SIZE))
        else:
            target_x = random.randint(area.left, max(area.left, area.right - self.SIZE))
        target_y = min(max(current_y, area.top), area.bottom - self.SIZE)

        self.facing = "right" if target_x >= current_x else "left"
        self._set_behavior(Behavior.WALK)
        self.target = (target_x, target_y)
        self.arrival_action = "siderest" if to_edge else None

    def _advance_walk(self):
        x, y = self._position()
        target_x, target_y = self.target
        speed = int(self.config["walk_speed"])
        delta_x = target_x - x
        delta_y = target_y - y

        if abs(delta_x) > 1:
            self.facing = "right" if delta_x > 0 else "left"

        distance = max(1.0, math.hypot(delta_x, delta_y))
        step = min(speed, distance)
        next_x = x + delta_x / distance * step
        next_y = y + delta_y / distance * step
        next_x, next_y = self._constrained_step(x, y, next_x, next_y)
        self._move(next_x, next_y)

        if int(next_x) == x and int(next_y) == y:
            self._set_behavior(Behavior.IDLE)
            self._schedule_auto(8, 15)
            return

        if distance <= speed:
            arrival_action = self.arrival_action
            self._move(target_x, target_y)
            if arrival_action == "siderest":
                self._set_behavior(Behavior.SIDEREST, animation="siderest", keep=True)
            else:
                self._set_behavior(Behavior.IDLE)
                self._schedule_auto(8, 15)

    def _horizontal_neighbor(self, area, direction):
        for other in self.areas:
            touches = other.right == area.left if direction < 0 else other.left == area.right
            overlap_top = max(area.top, other.top)
            overlap_bottom = min(area.bottom, other.bottom)
            if other != area and touches and overlap_bottom - overlap_top >= self.SIZE:
                return other, overlap_top, overlap_bottom
        return None

    def _constrained_step(self, x, y, next_x, next_y):
        current = area_at(x + self.SIZE // 2, y + self.SIZE // 2, self.areas)
        if current is None:
            current = nearest_area(x, y, self.areas)

        next_y = min(max(int(next_y), current.top), current.bottom - self.SIZE)
        next_x = int(next_x)

        if next_x > current.right - self.SIZE:
            connection = self._horizontal_neighbor(current, 1)
            if connection:
                other, overlap_top, overlap_bottom = connection
                if overlap_top <= next_y <= overlap_bottom - self.SIZE:
                    return min(next_x, other.right - self.SIZE), next_y
            return current.right - self.SIZE, next_y

        if next_x < current.left:
            connection = self._horizontal_neighbor(current, -1)
            if connection:
                other, overlap_top, overlap_bottom = connection
                if overlap_top <= next_y <= overlap_bottom - self.SIZE:
                    return max(next_x, other.left), next_y
            return current.left, next_y

        return next_x, next_y

    def _move_by_arrow(self, delta_x, delta_y):
        length = math.hypot(delta_x, delta_y)
        if not length:
            return

        speed = float(self.config["walk_speed"])
        x, y = self._position()
        next_x = x + delta_x / length * speed
        next_y = y + delta_y / length * speed
        next_x, next_y = self._constrained_step(x, y, next_x, next_y)

        if delta_x:
            self.facing = "right" if delta_x > 0 else "left"
        self._set_behavior(Behavior.WALK)
        self._move(next_x, next_y)

    def _follow_cursor(self):
        if self.mode != Mode.NORMAL:
            return

        cursor_x, cursor_y = cursor_position()
        area = area_at(cursor_x, cursor_y, self.areas)
        if area is None:
            area = nearest_area(cursor_x, cursor_y, self.areas)
        target_x, target_y = clamp_to_area(
            cursor_x - self.SIZE // 2 + 55,
            cursor_y - self.SIZE // 2 + 55,
            self.SIZE,
            self.SIZE,
            area,
        )
        current_x, _ = self._position()
        self.facing = "right" if target_x >= current_x else "left"
        self._set_behavior(Behavior.WALK)
        self.target = (target_x, target_y)

    def _can_pounce(self):
        x, y = self._position()
        cursor_x, cursor_y = cursor_position()
        cursor_area = area_at(cursor_x, cursor_y, self.areas)
        pet_area = area_at(x + self.SIZE // 2, y + self.SIZE // 2, self.areas)
        distance = math.hypot(cursor_x - x - self.SIZE // 2, cursor_y - y - self.SIZE // 2)
        return cursor_area is not None and cursor_area == pet_area and 100 <= distance <= 650

    def _start_crouch(self):
        self._set_behavior(Behavior.CROUCH, animation="crouch", keep=True)

    def _start_jump(self):
        self._begin_physics(random.choice((-3.5, 3.5)), -13.0, "pounce")

    def _launch_pounce(self):
        x, _ = self._position()
        cursor_x, _ = cursor_position()
        direction = 1 if cursor_x >= x + self.SIZE // 2 else -1
        self.facing = "right" if direction > 0 else "left"
        self._begin_physics(7.0 * direction, -11.5, "pounce")

    def _begin_physics(self, velocity_x, velocity_y, animation):
        if self.config["position_locked"]:
            return

        x, y = self._position()
        self.physics_area = area_at(x + self.SIZE // 2, y + self.SIZE // 2, self.areas)
        if self.physics_area is None:
            self.physics_area = nearest_area(x, y, self.areas)

        self.physics_floor = min(y, self.physics_area.bottom - self.SIZE)
        self.physics_vx = float(velocity_x)
        self.physics_vy = float(velocity_y)
        self.physics_anim = animation
        self._set_behavior(Behavior.PHYSICS, animation=animation, keep=True)

    def _advance_physics(self):
        if self.physics_area is None:
            self._set_behavior(Behavior.IDLE)
            return

        x, y = self._position()
        self.physics_vy += 0.72
        next_x = x + self.physics_vx
        next_y = y + self.physics_vy
        left = self.physics_area.left
        right = self.physics_area.right - self.SIZE

        if next_x <= left or next_x >= right:
            next_x = min(max(next_x, left), right)
            self.physics_vx *= -0.55
            self.facing = "right" if self.physics_vx > 0 else "left"

        if self.physics_vy > 0 and self.physics_anim != "fall":
            self.physics_anim = "fall"
            self.animation_override = "fall"
            self.behavior_since = time.monotonic()

        if next_y >= self.physics_floor:
            self._move(next_x, self.physics_floor)
            self.physics_area = None
            self._play_expression("stretch", 1.6, auto_kind="pounce")
            return

        self._move(next_x, max(next_y, self.physics_area.top))
