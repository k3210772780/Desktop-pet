from __future__ import annotations

import json
import tkinter as tk
from PIL import Image, UnidentifiedImageError
from .config import APP_DIR


class SpritePlayer:
    """Load sprite frames as RGBA images, preserving every alpha value."""

    REQUIRED_ACTIONS = ("idle", "eat", "walk", "sleep", "fall", "pet", "stretch",
                        "typing", "typingfast", "play", "drag", "crouch", "pounce",
                        "proud", "groom", "yawn", "loaf", "gift", "knockoff",
                        "siderest", "wakeup", "talk")

    def __init__(self, master: tk.Misc, scale_percent: int | None = None):
        self.asset_dir = APP_DIR / "assets" / "pixelpaws"
        self.available = False
        self.frames: dict[int, Image.Image] = {}
        self.mirrored_frames: dict[int, Image.Image] = {}
        self.animations = {}
        self.expression_menu = []
        self.default_facing = "right"
        self.error = None
        manifest_path = self.asset_dir / "manifest.json"
        if not manifest_path.exists():
            self.error = "找不到 manifest.json"
            return
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            sheet_path = self.asset_dir / str(manifest["sheet"])
            if not sheet_path.exists():
                raise ValueError(f"找不到皮肤图片：{sheet_path.name}")
            self.animations = manifest["animations"]
            self.expression_menu = self._validate_expression_menu(manifest.get("expressionMenu", []))
            with Image.open(sheet_path) as opened:
                source = opened.convert("RGBA")
            image_w, image_h = int(manifest["imageWidth"]), int(manifest["imageHeight"])
            cell_w, cell_h = int(manifest["cropWidth"]), int(manifest["cropHeight"])
            scale = int(scale_percent if scale_percent is not None else manifest.get("scalePercent", 50))
            self.default_facing = str(manifest.get("defaultFacing", "right"))
            if self.default_facing not in ("left", "right"):
                raise ValueError("defaultFacing 只能是 left 或 right")
            if min(image_w, image_h, cell_w, cell_h, scale) <= 0:
                raise ValueError("图片、裁剪尺寸和显示缩放必须为正数")
            if source.width != image_w or source.height != image_h:
                raise ValueError(
                    f"图片实际尺寸 {source.width}x{source.height} "
                    f"与 JSON 声明 {image_w}x{image_h} 不一致")
            if image_w % cell_w or image_h % cell_h:
                raise ValueError("图片宽高必须能被单帧裁剪宽高整除")
            columns, rows = image_w // cell_w, image_h // cell_h
            frame_count = columns * rows
            self._validate_animations(frame_count)
            rendered_w = max(1, round(cell_w * scale / 100))
            rendered_h = max(1, round(cell_h * scale / 100))
            indices = {i for spec in self.animations.values() for i in spec["frames"]}
            for index in indices:
                x = (index % columns) * cell_w
                y = (index // columns) * cell_h
                frame = source.crop((x, y, x + cell_w, y + cell_h))
                rendered = frame.resize(
                    (rendered_w, rendered_h),
                    Image.Resampling.NEAREST,
                )
                mirrored = rendered.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                if self.default_facing == "left":
                    rendered, mirrored = mirrored, rendered
                self.frames[index] = rendered
                self.mirrored_frames[index] = mirrored
            self.available = bool(self.frames)
        except (KeyError, OSError, TypeError, ValueError, UnidentifiedImageError) as exc:
            self.error = str(exc)
            self.available = False
            self.expression_menu = []
            self.frames.clear()
            self.mirrored_frames.clear()

    def _validate_animations(self, frame_count: int) -> None:
        if not isinstance(self.animations, dict) or not self.animations:
            raise ValueError("animations 必须包含至少一个动作")
        missing = [action for action in self.REQUIRED_ACTIONS if action not in self.animations]
        if missing:
            raise ValueError("缺少必须动作：" + ", ".join(missing))
        for action, spec in self.animations.items():
            frames = spec.get("frames") if isinstance(spec, dict) else None
            if not isinstance(frames, list) or not frames:
                raise ValueError(f"动作 {action} 没有有效帧列表")
            if any(not isinstance(i, int) or i < 0 or i >= frame_count for i in frames):
                raise ValueError(f"动作 {action} 使用了超出图片范围的帧")
            if float(spec.get("fps", 0)) <= 0:
                raise ValueError(f"动作 {action} 的 fps 必须大于 0")

    def _validate_expression_menu(self, items) -> list[dict]:
        if not isinstance(items, list):
            raise ValueError("expressionMenu 必须是列表")
        result = []
        for item in items:
            if not isinstance(item, dict):
                raise ValueError("expressionMenu 的每一项必须是对象")
            name, action = str(item.get("name", "")).strip(), str(item.get("action", "")).strip()
            duration = float(item.get("duration", 3.0))
            if not name or action not in self.animations or duration <= 0:
                raise ValueError(f"无效的表情菜单项：{item}")
            result.append({"name": name, "action": action, "duration": duration})
        return result

    def _animation_spec(self, animation: str):
        return self.animations.get(animation) or self.animations.get("idle")

    def frame(self, animation: str, elapsed: float, facing: str = "right") -> Image.Image | None:
        spec = self._animation_spec(animation)
        if not self.available or not spec:
            return None
        sequence = spec["frames"]
        offset = int(elapsed * float(spec["fps"]))
        if spec.get("loop", True):
            offset %= len(sequence)
        else:
            offset = min(offset, len(sequence) - 1)
        bank = self.mirrored_frames if facing == "left" else self.frames
        return bank.get(sequence[offset])
